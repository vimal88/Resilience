/*******************************************************************************
** 
** Filename: tincanwrapper.js
**
** File Description: This file contains the wrapper functions that allows the content 
**                   to access the Tin Can functions in the titlemgr frameset.
**
** References: Tin Can API
**
*******************************************************************************/

var finishCalled = false;
var autoCommit = false;

function MySetValue( lmsVar, lmsVal ) {
  var titleMgr = getTitleMgrHandle();
  if( titleMgr ) titleMgr.setVariable(lmsVar,lmsVal,0)
  LMSSetValue( lmsVar, lmsVal )
}

function loadPage() {
  var startDate = readVariable( 'TrivantisSCORMTimer', 0 );
  saveVariable( 'TrivantisEPS', 'F' );
  if( startDate == 0 || !LMSIsInitialized() ) {
    var result = LMSInitialize();
    var status = new String( LMSGetValue( "cmi.core.lesson_status" ) );
    status = status.toLowerCase();
    if (status == "not attempted") 
        MySetValue( "cmi.core.lesson_status", "attempted" );

    startTimer();
    return true;
  }
  else return false;
}

function startTimer() {
  var startDate = new Date().getTime();
  saveVariable('TrivantisSCORMTimer',startDate)
}

function doBack() {
  MySetValue( "cmi.core.exit", "suspend" );
  saveVariable( 'TrivantisEPS', 'T' );
  finishCalled = true;
  var result = LMSFinish();
  saveVariable( 'TrivantisSCORMTimer', 0 );
}

function doContinue( status ) {
  MySetValue( "cmi.core.exit", "" );
  var mode = new String( LMSGetValue( "cmi.core.lesson_mode" ) );
  mode = mode.toLowerCase()
  if ( mode != "review"  &&  mode != "browse" ) MySetValue( "cmi.core.lesson_status", status );
  saveVariable( 'TrivantisEPS', 'T' );
  finishCalled = true;
  var result = LMSFinish();
  saveVariable( 'TrivantisSCORMTimer', 0 );
}

function doQuit(bForce){
  saveVariable( 'TrivantisEPS', 'T' );
  finishCalled = true;
  var result = LMSFinish();
  saveVariable( 'TrivantisSCORMTimer', 0 );
  if(bForce) parent.top.close()
}

function unloadPage(bForce) {
  var exitPageStatus = readVariable( 'TrivantisEPS', 'F' );
  if (exitPageStatus != 'T') {
    if( window.name.length > 0 && window.name.indexOf( 'Trivantis_' ) == -1 ) doQuit(bForce);
  }
}


var _Debug = false;  // set this to false to turn debugging off

function findxAPI(win) 
{

   // Search the window hierarchy for the TitleMgr Frame.

   if (_Debug)
   {
      alert("win is: "+win.location.href);
   }

   if (win.length > 0)  // does the window have frames?
   {
      if (win.frames['titlemgrframe'] != null)
      {
         if (_Debug)
         {
            alert("found xAPI in this window");
         }
         return win.frames['titlemgrframe'];
      }
   
      if (_Debug)
      {
         alert("looking for xAPI in windows frames");
      }

      for (var i=0;i<win.length;i++)
      {

         if (_Debug)
         {
            alert("looking for xAPI in frames["+i+"]");
         }
         var theAPI = findxAPI(win.frames[i]);
         if (theAPI != null)
         {
            return theAPI;
         }
      }
   }

   if (_Debug)
   {
      alert("didn't find xAPI in this window (or its children)");
   }
   return null;
}

var tcAPI = findxAPI(this.top);

function LMSInitialize()
{
   return tcAPI.LMSInitialize();
}

function LMSFinish()
{
   return tcAPI.LMSFinish();
}

function LMSGetValue(name)
{
   return tcAPI.LMSGetValue(name);
}

function LMSSetValue(name, value)
{
   return tcAPI.LMSSetValue(name, value);
}

function LMSCommit()
{
   return tcAPI.LMSCommit();
}

function LMSGetLastError()
{
   return tcAPI.LMSGetLastError();
}

function LMSGetErrorString(errorCode)
{
   return tcAPI.LMSGetErrorString(errorCode);
}

function LMSGetDiagnostic(errorCode)
{
   return tcAPI.LMSGetDiagnostic(errorCode);
}

function LMSGetBookmark()
{
   return tcAPI.LMSGetBookmark();
}

function LMSSetBookmark(strHtml,strName)
{
   return tcAPI.LMSSetBookmark(strHtml,strName);
}

function putSCORMInteractions(id,obj,tim,typ,crsp,wgt,srsp,res,lat,txt) 
{
  return tcAPI.putSCORMInteractions(id,obj,tim,typ,crsp,wgt,srsp,res,lat,txt);
}

function LMSTinCanStatement(strVerb,strObj)
{
   return tcAPI.LMSTinCanStatement(strVerb,strObj);
}