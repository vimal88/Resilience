TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image5712":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_icon.png"}
,
"shape23327":{"x":-2,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape23327.png"}
,
"image23506":{"x":0,"y":128,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"shape141298":{"x":-90,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape141298.png"}
,
"shape231677":{"x":-90,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape231677.png"}
,
"shape231747":{"x":-90,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape231747.png"}
,
"shape231826":{"x":-90,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape231826.png"}
,
"image24751":{"x":0,"y":0,"w":1010,"h":662,"i":"images/bg.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button21550.png","irol":"images/TabletLandscape_button21550_over.png","ion":"images/TabletLandscape_button21550_down.png","idis":"images/TabletLandscape_button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button21689.png","irol":"images/TabletLandscape_button21689_over.png","ion":"images/TabletLandscape_button21689_down.png","idis":"images/TabletLandscape_button21689_disabled.png"}
,
"text24400":{"x":201,"y":17,"w":607,"h":35,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365085.png"}
,
"image22840":{"x":14,"y":145,"w":548,"h":425,"i":"images/video_cover.png"}
,
"text22747":{"x":201,"y":88,"w":607,"h":42,"txtscale":100}
,
"text24381":{"x":589,"y":277,"w":349,"h":161,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_icon.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/bg.png','images/video_cover.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_button21550.png','images/TabletLandscape_button21550_over.png','images/TabletLandscape_button21550_down.png','images/TabletLandscape_button21550_disabled.png','images/TabletLandscape_button21689.png','images/TabletLandscape_button21689_over.png','images/TabletLandscape_button21689_down.png','images/TabletLandscape_button21689_disabled.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff"}
,
"image5712":{"x":14,"y":14,"w":30,"h":27,"i":"images/menu_icon.png"}
,
"shape23327":{"x":-2,"y":-1,"w":789,"h":101,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:781px; height:93px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:781px; height:93px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape23327.png"}
,
"image23506":{"x":0,"y":97,"w":785,"h":903,"i":"images/menu_bg.png"}
,
"image23329":{"x":15,"y":10,"w":26,"h":38,"i":"images/menu_hide.png"}
,
"image23332":{"x":348,"y":10,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":163,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":217,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":272,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":325,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":379,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":433,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":487,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":541,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":109,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":164,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":218,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":272,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":326,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":380,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":434,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":488,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":124,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":0,"y":179,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":0,"y":234,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":0,"y":288,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":0,"y":342,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":0,"y":395,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":0,"y":449,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":0,"y":503,"w":785,"h":31,"txtscale":100}
,
"shape141298":{"x":-70,"y":125,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape141298.png"}
,
"shape231677":{"x":-70,"y":185,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape231677.png"}
,
"shape231747":{"x":-70,"y":245,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape231747.png"}
,
"shape231826":{"x":-70,"y":305,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape231826.png"}
,
"image24751":{"x":0,"y":0,"w":786,"h":1000,"i":"images/bg.png"}
,
"button21550":{"x":105,"y":919,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button21550.png","irol":"images/TabletPortrait_button21550_over.png","ion":"images/TabletPortrait_button21550_down.png","idis":"images/TabletPortrait_button21550_disabled.png"}
,
"button21689":{"x":607,"y":919,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button21689.png","irol":"images/TabletPortrait_button21689_over.png","ion":"images/TabletPortrait_button21689_down.png","idis":"images/TabletPortrait_button21689_disabled.png"}
,
"text24400":{"x":156,"y":17,"w":472,"h":33,"txtscale":100}
,
"shape365091":{"x":203,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365091.png"}
,
"shape365089":{"x":295,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365089.png"}
,
"shape365087":{"x":387,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365087.png"}
,
"shape365085":{"x":479,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365085.png"}
,
"image22840":{"x":85,"y":145,"w":614,"h":476,"i":"images/video_cover.png"}
,
"text22747":{"x":156,"y":88,"w":472,"h":48,"txtscale":100}
,
"text24381":{"x":111,"y":649,"w":558,"h":176,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_icon.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/bg.png','images/video_cover.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_button21550.png','images/TabletPortrait_button21550_over.png','images/TabletPortrait_button21550_down.png','images/TabletPortrait_button21550_disabled.png','images/TabletPortrait_button21689.png','images/TabletPortrait_button21689_over.png','images/TabletPortrait_button21689_down.png','images/TabletPortrait_button21689_disabled.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png']
}}
