TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image38007":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape23327.png"}
,
"image23506":{"x":0,"y":128,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"button278429":{"x":542,"y":197,"w":173,"h":70,"stylemods":[{"sel":"div.button278429Text","decl":" { position:absolute; left:6px; top:2px; width:157px; height:62px;}"},{"sel":"span.button278429Text","decl":" { display:table-cell; position:relative; width:157px; height:62px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278429.png","irol":"images/TabletLandscape_button278429_over.png","ion":"images/TabletLandscape_button278429_down.png","idis":"images/TabletLandscape_button278429_disabled.png"}
,
"button278440":{"x":557,"y":283,"w":62,"h":56,"stylemods":[{"sel":"div.button278440Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278440Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278440.png","irol":"images/TabletLandscape_button278440_over.png","ion":"images/TabletLandscape_button278440_down.png","idis":"images/TabletLandscape_button278440_disabled.png"}
,
"button278447":{"x":647,"y":283,"w":62,"h":56,"stylemods":[{"sel":"div.button278447Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278447Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278447.png","irol":"images/TabletLandscape_button278447_over.png","ion":"images/TabletLandscape_button278447_down.png","idis":"images/TabletLandscape_button278447_disabled.png"}
,
"button278454":{"x":557,"y":340,"w":62,"h":56,"stylemods":[{"sel":"div.button278454Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278454Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278454.png","irol":"images/TabletLandscape_button278454_over.png","ion":"images/TabletLandscape_button278454_down.png","idis":"images/TabletLandscape_button278454_disabled.png"}
,
"button278461":{"x":647,"y":340,"w":62,"h":56,"stylemods":[{"sel":"div.button278461Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278461Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278461.png","irol":"images/TabletLandscape_button278461_over.png","ion":"images/TabletLandscape_button278461_down.png","idis":"images/TabletLandscape_button278461_disabled.png"}
,
"button278468":{"x":557,"y":397,"w":62,"h":56,"stylemods":[{"sel":"div.button278468Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278468Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278468.png","irol":"images/TabletLandscape_button278468_over.png","ion":"images/TabletLandscape_button278468_down.png","idis":"images/TabletLandscape_button278468_disabled.png"}
,
"button278475":{"x":647,"y":397,"w":62,"h":56,"stylemods":[{"sel":"div.button278475Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278475Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278475.png","irol":"images/TabletLandscape_button278475_over.png","ion":"images/TabletLandscape_button278475_down.png","idis":"images/TabletLandscape_button278475_disabled.png"}
,
"button278482":{"x":557,"y":454,"w":62,"h":56,"stylemods":[{"sel":"div.button278482Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278482Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278482.png","irol":"images/TabletLandscape_button278482_over.png","ion":"images/TabletLandscape_button278482_down.png","idis":"images/TabletLandscape_button278482_disabled.png"}
,
"button278489":{"x":647,"y":454,"w":62,"h":56,"stylemods":[{"sel":"div.button278489Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278489Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278489.png","irol":"images/TabletLandscape_button278489_over.png","ion":"images/TabletLandscape_button278489_down.png","idis":"images/TabletLandscape_button278489_disabled.png"}
,
"button278879":{"x":557,"y":514,"w":62,"h":56,"stylemods":[{"sel":"div.button278879Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278879Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278879.png","irol":"images/TabletLandscape_button278879_over.png","ion":"images/TabletLandscape_button278879_down.png","idis":"images/TabletLandscape_button278879_disabled.png"}
,
"button278872":{"x":647,"y":514,"w":62,"h":56,"stylemods":[{"sel":"div.button278872Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278872Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button278872.png","irol":"images/TabletLandscape_button278872_over.png","ion":"images/TabletLandscape_button278872_down.png","idis":"images/TabletLandscape_button278872_disabled.png"}
,
"shape141298":{"x":-90,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape141298.png"}
,
"shape231677":{"x":-90,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape231677.png"}
,
"shape231747":{"x":-90,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape231747.png"}
,
"shape231826":{"x":-90,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":1012,"h":585,"i":"images/bg_voilet.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button21550.png","irol":"images/TabletLandscape_button21550_over.png","ion":"images/TabletLandscape_button21550_down.png","idis":"images/TabletLandscape_button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_button21689.png","irol":"images/TabletLandscape_button21689_over.png","ion":"images/TabletLandscape_button21689_down.png","idis":"images/TabletLandscape_button21689_disabled.png"}
,
"text38077":{"x":201,"y":17,"w":607,"h":36,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape365085.png"}
,
"shape366845":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape366845.png"}
,
"shape366843":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape366843.png"}
,
"shape366841":{"x":378,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape366841.png"}
,
"image278373":{"x":257,"y":71,"w":494,"h":520,"i":"images/text_bg.png"}
,
"text278374":{"x":201,"y":88,"w":607,"h":53,"txtscale":100}
,
"text278375":{"x":286,"y":139,"w":437,"h":85,"txtscale":100}
,
"text278376":{"x":284,"y":226,"w":242,"h":37,"txtscale":100}
,
"text278377":{"x":286,"y":263,"w":253,"h":35,"txtscale":100}
,
"text278378":{"x":286,"y":301,"w":267,"h":30,"txtscale":100}
,
"text278379":{"x":286,"y":356,"w":222,"h":35,"txtscale":100}
,
"text278380":{"x":286,"y":413,"w":266,"h":35,"txtscale":100}
,
"text278381":{"x":286,"y":464,"w":269,"h":35,"txtscale":100}
,
"text278892":{"x":286,"y":524,"w":269,"h":35,"txtscale":100}
,
"image278383":{"x":546,"y":197,"w":170,"h":70,"i":"images/remind_me.png"}
,
"text278384":{"x":607,"y":221,"w":101,"h":29,"txtscale":100}
,
"image278386":{"x":562,"y":286,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278388":{"x":560,"y":283,"w":60,"h":56,"i":"images/selected.png"}
,
"image278390":{"x":652,"y":286,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278392":{"x":651,"y":283,"w":60,"h":56,"i":"images/selected.png"}
,
"image278394":{"x":562,"y":341,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278396":{"x":560,"y":340,"w":60,"h":56,"i":"images/selected.png"}
,
"image278398":{"x":652,"y":341,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278400":{"x":651,"y":340,"w":60,"h":56,"i":"images/selected.png"}
,
"image278402":{"x":562,"y":398,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278404":{"x":560,"y":397,"w":60,"h":56,"i":"images/selected.png"}
,
"image278406":{"x":652,"y":398,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278408":{"x":651,"y":397,"w":60,"h":56,"i":"images/selected.png"}
,
"image278410":{"x":562,"y":455,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278412":{"x":560,"y":454,"w":60,"h":56,"i":"images/selected.png"}
,
"image278414":{"x":652,"y":455,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278416":{"x":651,"y":454,"w":60,"h":56,"i":"images/selected.png"}
,
"image278891":{"x":562,"y":515,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278889":{"x":560,"y":514,"w":60,"h":56,"i":"images/selected.png"}
,
"image278887":{"x":652,"y":515,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278885":{"x":651,"y":514,"w":60,"h":56,"i":"images/selected.png"}
,
"text278417":{"x":567,"y":303,"w":49,"h":27,"txtscale":100}
,
"text278418":{"x":656,"y":303,"w":49,"h":27,"txtscale":100}
,
"text278419":{"x":656,"y":358,"w":49,"h":27,"txtscale":100}
,
"text278420":{"x":567,"y":415,"w":49,"h":27,"txtscale":100}
,
"text278421":{"x":656,"y":471,"w":49,"h":27,"txtscale":100}
,
"text278422":{"x":567,"y":471,"w":49,"h":27,"txtscale":100}
,
"text278423":{"x":656,"y":415,"w":49,"h":27,"txtscale":100}
,
"text278424":{"x":567,"y":358,"w":49,"h":27,"txtscale":100}
,
"text278882":{"x":567,"y":531,"w":49,"h":27,"txtscale":100}
,
"text278883":{"x":656,"y":531,"w":49,"h":27,"txtscale":100}
,
"shape278500":{"x":270,"y":275,"w":455,"h":280,"stylemods":[{"sel":"div.shape278500Text","decl":" { position:absolute; left:5px; top:2px; width:441px; height:272px;}"},{"sel":"span.shape278500Text","decl":" { display:table-cell; position:relative; width:441px; height:272px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletLandscape_shape278500.png"}
,
"text278501":{"x":316,"y":297,"w":405,"h":46,"txtscale":100}
,
"text278502":{"x":316,"y":348,"w":405,"h":46,"txtscale":100}
,
"text278503":{"x":316,"y":399,"w":405,"h":46,"txtscale":100}
,
"text278504":{"x":316,"y":450,"w":405,"h":46,"txtscale":100}
,
"text278505":{"x":316,"y":501,"w":405,"h":46,"txtscale":100}
,
"text324690":{"x":275,"y":298,"w":34,"h":33,"txtscale":100}
,
"text324689":{"x":275,"y":349,"w":34,"h":33,"txtscale":100}
,
"text324688":{"x":275,"y":400,"w":34,"h":33,"txtscale":100}
,
"text324687":{"x":275,"y":451,"w":34,"h":33,"txtscale":100}
,
"text324686":{"x":275,"y":502,"w":34,"h":33,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/remind_me.png','images/yes_n_no.png','images/selected.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_button21550.png','images/TabletLandscape_button21550_over.png','images/TabletLandscape_button21550_down.png','images/TabletLandscape_button21550_disabled.png','images/TabletLandscape_button21689.png','images/TabletLandscape_button21689_over.png','images/TabletLandscape_button21689_down.png','images/TabletLandscape_button21689_disabled.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape23327.png','images/TabletLandscape_button278429.png','images/TabletLandscape_button278429_over.png','images/TabletLandscape_button278429_down.png','images/TabletLandscape_button278429_disabled.png','images/TabletLandscape_button278440.png','images/TabletLandscape_button278440_over.png','images/TabletLandscape_button278440_down.png','images/TabletLandscape_button278440_disabled.png','images/TabletLandscape_button278447.png','images/TabletLandscape_button278447_over.png','images/TabletLandscape_button278447_down.png','images/TabletLandscape_button278447_disabled.png','images/TabletLandscape_button278454.png','images/TabletLandscape_button278454_over.png','images/TabletLandscape_button278454_down.png','images/TabletLandscape_button278454_disabled.png','images/TabletLandscape_button278461.png','images/TabletLandscape_button278461_over.png','images/TabletLandscape_button278461_down.png','images/TabletLandscape_button278461_disabled.png','images/TabletLandscape_button278468.png','images/TabletLandscape_button278468_over.png','images/TabletLandscape_button278468_down.png','images/TabletLandscape_button278468_disabled.png','images/TabletLandscape_button278475.png','images/TabletLandscape_button278475_over.png','images/TabletLandscape_button278475_down.png','images/TabletLandscape_button278475_disabled.png','images/TabletLandscape_button278482.png','images/TabletLandscape_button278482_over.png','images/TabletLandscape_button278482_down.png','images/TabletLandscape_button278482_disabled.png','images/TabletLandscape_button278489.png','images/TabletLandscape_button278489_over.png','images/TabletLandscape_button278489_down.png','images/TabletLandscape_button278489_disabled.png','images/TabletLandscape_button278879.png','images/TabletLandscape_button278879_over.png','images/TabletLandscape_button278879_down.png','images/TabletLandscape_button278879_disabled.png','images/TabletLandscape_button278872.png','images/TabletLandscape_button278872_over.png','images/TabletLandscape_button278872_down.png','images/TabletLandscape_button278872_disabled.png','images/TabletLandscape_shape141298.png','images/TabletLandscape_shape231677.png','images/TabletLandscape_shape231747.png','images/TabletLandscape_shape231826.png','images/TabletLandscape_shape365091.png','images/TabletLandscape_shape365089.png','images/TabletLandscape_shape365087.png','images/TabletLandscape_shape365085.png','images/TabletLandscape_shape366845.png','images/TabletLandscape_shape366843.png','images/TabletLandscape_shape366841.png','images/TabletLandscape_shape278500.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff"}
,
"image38007":{"x":14,"y":14,"w":30,"h":27,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":789,"h":101,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:781px; height:93px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:781px; height:93px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape23327.png"}
,
"image23506":{"x":0,"y":97,"w":785,"h":903,"i":"images/menu_bg.png"}
,
"image23329":{"x":15,"y":10,"w":26,"h":38,"i":"images/menu_hide.png"}
,
"image23332":{"x":348,"y":10,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":163,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":217,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":272,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":325,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":379,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":433,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":487,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":541,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":109,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":164,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":218,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":272,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":326,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":380,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":434,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":488,"w":785,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":124,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":0,"y":179,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":0,"y":234,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":0,"y":288,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":0,"y":342,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":0,"y":395,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":0,"y":449,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":0,"y":503,"w":785,"h":31,"txtscale":100}
,
"button278429":{"x":332,"y":216,"w":135,"h":55,"stylemods":[{"sel":"div.button278429Text","decl":" { position:absolute; left:5px; top:2px; width:121px; height:47px;}"},{"sel":"span.button278429Text","decl":" { display:table-cell; position:relative; width:121px; height:47px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278429.png","irol":"images/TabletPortrait_button278429_over.png","ion":"images/TabletPortrait_button278429_down.png","idis":"images/TabletPortrait_button278429_disabled.png"}
,
"button278440":{"x":459,"y":356,"w":62,"h":56,"stylemods":[{"sel":"div.button278440Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278440Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278440.png","irol":"images/TabletPortrait_button278440_over.png","ion":"images/TabletPortrait_button278440_down.png","idis":"images/TabletPortrait_button278440_disabled.png"}
,
"button278447":{"x":528,"y":356,"w":62,"h":56,"stylemods":[{"sel":"div.button278447Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278447Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278447.png","irol":"images/TabletPortrait_button278447_over.png","ion":"images/TabletPortrait_button278447_down.png","idis":"images/TabletPortrait_button278447_disabled.png"}
,
"button278454":{"x":458,"y":414,"w":62,"h":56,"stylemods":[{"sel":"div.button278454Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278454Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278454.png","irol":"images/TabletPortrait_button278454_over.png","ion":"images/TabletPortrait_button278454_down.png","idis":"images/TabletPortrait_button278454_disabled.png"}
,
"button278461":{"x":529,"y":413,"w":62,"h":56,"stylemods":[{"sel":"div.button278461Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278461Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278461.png","irol":"images/TabletPortrait_button278461_over.png","ion":"images/TabletPortrait_button278461_down.png","idis":"images/TabletPortrait_button278461_disabled.png"}
,
"button278468":{"x":458,"y":473,"w":62,"h":56,"stylemods":[{"sel":"div.button278468Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278468Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278468.png","irol":"images/TabletPortrait_button278468_over.png","ion":"images/TabletPortrait_button278468_down.png","idis":"images/TabletPortrait_button278468_disabled.png"}
,
"button278475":{"x":529,"y":472,"w":62,"h":56,"stylemods":[{"sel":"div.button278475Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278475Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278475.png","irol":"images/TabletPortrait_button278475_over.png","ion":"images/TabletPortrait_button278475_down.png","idis":"images/TabletPortrait_button278475_disabled.png"}
,
"button278482":{"x":459,"y":531,"w":62,"h":56,"stylemods":[{"sel":"div.button278482Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278482Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278482.png","irol":"images/TabletPortrait_button278482_over.png","ion":"images/TabletPortrait_button278482_down.png","idis":"images/TabletPortrait_button278482_disabled.png"}
,
"button278489":{"x":529,"y":530,"w":62,"h":56,"stylemods":[{"sel":"div.button278489Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278489Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278489.png","irol":"images/TabletPortrait_button278489_over.png","ion":"images/TabletPortrait_button278489_down.png","idis":"images/TabletPortrait_button278489_disabled.png"}
,
"button278879":{"x":459,"y":591,"w":62,"h":56,"stylemods":[{"sel":"div.button278879Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278879Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278879.png","irol":"images/TabletPortrait_button278879_over.png","ion":"images/TabletPortrait_button278879_down.png","idis":"images/TabletPortrait_button278879_disabled.png"}
,
"button278872":{"x":529,"y":590,"w":62,"h":56,"stylemods":[{"sel":"div.button278872Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278872Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button278872.png","irol":"images/TabletPortrait_button278872_over.png","ion":"images/TabletPortrait_button278872_down.png","idis":"images/TabletPortrait_button278872_disabled.png"}
,
"shape141298":{"x":-70,"y":125,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape141298.png"}
,
"shape231677":{"x":-70,"y":185,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape231677.png"}
,
"shape231747":{"x":-70,"y":245,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape231747.png"}
,
"shape231826":{"x":-70,"y":305,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":786,"h":900,"i":"images/bg_voilet.png"}
,
"button21550":{"x":105,"y":919,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button21550.png","irol":"images/TabletPortrait_button21550_over.png","ion":"images/TabletPortrait_button21550_down.png","idis":"images/TabletPortrait_button21550_disabled.png"}
,
"button21689":{"x":607,"y":919,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_button21689.png","irol":"images/TabletPortrait_button21689_over.png","ion":"images/TabletPortrait_button21689_down.png","idis":"images/TabletPortrait_button21689_disabled.png"}
,
"text38077":{"x":156,"y":17,"w":472,"h":33,"txtscale":100}
,
"shape365091":{"x":203,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365091.png"}
,
"shape365089":{"x":295,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365089.png"}
,
"shape365087":{"x":387,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365087.png"}
,
"shape365085":{"x":479,"y":943,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape365085.png"}
,
"shape366845":{"x":204,"y":943,"w":48,"h":13,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape366845.png"}
,
"shape366843":{"x":250,"y":943,"w":48,"h":13,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape366843.png"}
,
"shape366841":{"x":296,"y":943,"w":48,"h":13,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape366841.png"}
,
"image278373":{"x":153,"y":71,"w":479,"h":611,"i":"images/text_bg.png"}
,
"text278374":{"x":156,"y":88,"w":472,"h":48,"txtscale":100}
,
"text278375":{"x":177,"y":139,"w":427,"h":182,"txtscale":100}
,
"text278376":{"x":177,"y":290,"w":427,"h":37,"txtscale":100}
,
"text278377":{"x":177,"y":328,"w":197,"h":27,"txtscale":100}
,
"text278378":{"x":177,"y":370,"w":270,"h":33,"txtscale":100}
,
"text278379":{"x":177,"y":428,"w":250,"h":30,"txtscale":100}
,
"text278380":{"x":177,"y":486,"w":250,"h":30,"txtscale":100}
,
"text278381":{"x":177,"y":542,"w":250,"h":30,"txtscale":100}
,
"text278892":{"x":177,"y":602,"w":250,"h":30,"txtscale":100}
,
"image278383":{"x":336,"y":216,"w":132,"h":54,"i":"images/remind_me.png"}
,
"text278384":{"x":383,"y":221,"w":79,"h":52,"txtscale":100}
,
"image278386":{"x":464,"y":359,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278388":{"x":462,"y":356,"w":60,"h":56,"i":"images/selected.png"}
,
"image278390":{"x":534,"y":359,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278392":{"x":532,"y":356,"w":60,"h":56,"i":"images/selected.png"}
,
"image278394":{"x":464,"y":417,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278396":{"x":462,"y":413,"w":60,"h":56,"i":"images/selected.png"}
,
"image278398":{"x":534,"y":417,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278400":{"x":532,"y":413,"w":60,"h":56,"i":"images/selected.png"}
,
"image278402":{"x":464,"y":475,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278404":{"x":462,"y":472,"w":60,"h":56,"i":"images/selected.png"}
,
"image278406":{"x":534,"y":475,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278408":{"x":532,"y":472,"w":60,"h":56,"i":"images/selected.png"}
,
"image278410":{"x":464,"y":531,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278412":{"x":462,"y":530,"w":60,"h":56,"i":"images/selected.png"}
,
"image278414":{"x":534,"y":531,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278416":{"x":532,"y":530,"w":60,"h":56,"i":"images/selected.png"}
,
"image278891":{"x":464,"y":591,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278889":{"x":462,"y":590,"w":60,"h":56,"i":"images/selected.png"}
,
"image278887":{"x":534,"y":591,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278885":{"x":532,"y":590,"w":60,"h":56,"i":"images/selected.png"}
,
"text278417":{"x":474,"y":376,"w":38,"h":24,"txtscale":100}
,
"text278418":{"x":544,"y":376,"w":38,"h":24,"txtscale":100}
,
"text278419":{"x":544,"y":434,"w":38,"h":24,"txtscale":100}
,
"text278420":{"x":474,"y":491,"w":38,"h":24,"txtscale":100}
,
"text278421":{"x":544,"y":546,"w":38,"h":24,"txtscale":100}
,
"text278422":{"x":474,"y":546,"w":38,"h":24,"txtscale":100}
,
"text278423":{"x":544,"y":491,"w":38,"h":24,"txtscale":100}
,
"text278424":{"x":474,"y":434,"w":38,"h":24,"txtscale":100}
,
"text278882":{"x":474,"y":606,"w":38,"h":24,"txtscale":100}
,
"text278883":{"x":544,"y":606,"w":38,"h":24,"txtscale":100}
,
"shape278500":{"x":167,"y":287,"w":446,"h":306,"stylemods":[{"sel":"div.shape278500Text","decl":" { position:absolute; left:5px; top:2px; width:432px; height:298px;}"},{"sel":"span.shape278500Text","decl":" { display:table-cell; position:relative; width:432px; height:298px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/TabletPortrait_shape278500.png"}
,
"text278501":{"x":200,"y":300,"w":405,"h":46,"txtscale":100}
,
"text278502":{"x":200,"y":356,"w":405,"h":46,"txtscale":100}
,
"text278503":{"x":200,"y":412,"w":405,"h":46,"txtscale":100}
,
"text278504":{"x":200,"y":468,"w":405,"h":46,"txtscale":100}
,
"text278505":{"x":200,"y":524,"w":405,"h":46,"txtscale":100}
,
"text324690":{"x":169,"y":300,"w":26,"h":26,"txtscale":100}
,
"text324689":{"x":169,"y":359,"w":26,"h":26,"txtscale":100}
,
"text324688":{"x":169,"y":418,"w":26,"h":26,"txtscale":100}
,
"text324687":{"x":169,"y":476,"w":26,"h":26,"txtscale":100}
,
"text324686":{"x":169,"y":535,"w":26,"h":26,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/remind_me.png','images/yes_n_no.png','images/selected.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_button21550.png','images/TabletPortrait_button21550_over.png','images/TabletPortrait_button21550_down.png','images/TabletPortrait_button21550_disabled.png','images/TabletPortrait_button21689.png','images/TabletPortrait_button21689_over.png','images/TabletPortrait_button21689_down.png','images/TabletPortrait_button21689_disabled.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape23327.png','images/TabletPortrait_button278429.png','images/TabletPortrait_button278429_over.png','images/TabletPortrait_button278429_down.png','images/TabletPortrait_button278429_disabled.png','images/TabletPortrait_button278440.png','images/TabletPortrait_button278440_over.png','images/TabletPortrait_button278440_down.png','images/TabletPortrait_button278440_disabled.png','images/TabletPortrait_button278447.png','images/TabletPortrait_button278447_over.png','images/TabletPortrait_button278447_down.png','images/TabletPortrait_button278447_disabled.png','images/TabletPortrait_button278454.png','images/TabletPortrait_button278454_over.png','images/TabletPortrait_button278454_down.png','images/TabletPortrait_button278454_disabled.png','images/TabletPortrait_button278461.png','images/TabletPortrait_button278461_over.png','images/TabletPortrait_button278461_down.png','images/TabletPortrait_button278461_disabled.png','images/TabletPortrait_button278468.png','images/TabletPortrait_button278468_over.png','images/TabletPortrait_button278468_down.png','images/TabletPortrait_button278468_disabled.png','images/TabletPortrait_button278475.png','images/TabletPortrait_button278475_over.png','images/TabletPortrait_button278475_down.png','images/TabletPortrait_button278475_disabled.png','images/TabletPortrait_button278482.png','images/TabletPortrait_button278482_over.png','images/TabletPortrait_button278482_down.png','images/TabletPortrait_button278482_disabled.png','images/TabletPortrait_button278489.png','images/TabletPortrait_button278489_over.png','images/TabletPortrait_button278489_down.png','images/TabletPortrait_button278489_disabled.png','images/TabletPortrait_button278879.png','images/TabletPortrait_button278879_over.png','images/TabletPortrait_button278879_down.png','images/TabletPortrait_button278879_disabled.png','images/TabletPortrait_button278872.png','images/TabletPortrait_button278872_over.png','images/TabletPortrait_button278872_down.png','images/TabletPortrait_button278872_disabled.png','images/TabletPortrait_shape141298.png','images/TabletPortrait_shape231677.png','images/TabletPortrait_shape231747.png','images/TabletPortrait_shape231826.png','images/TabletPortrait_shape365091.png','images/TabletPortrait_shape365089.png','images/TabletPortrait_shape365087.png','images/TabletPortrait_shape365085.png','images/TabletPortrait_shape366845.png','images/TabletPortrait_shape366843.png','images/TabletPortrait_shape366841.png','images/TabletPortrait_shape278500.png']
}}
