PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"image38007":{"x":14,"y":11,"w":30,"h":27,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":139,"y":-56,"w":790,"h":90,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:782px; height:82px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:782px; height:82px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape23327.png"}
,
"image23506":{"x":141,"y":24,"w":785,"h":372,"i":"images/menu_bg.png"}
,
"image23329":{"x":156,"y":-47,"w":20,"h":29,"i":"images/menu_hide.png"}
,
"image23332":{"x":497,"y":-46,"w":72,"h":63,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":141,"y":70,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":141,"y":113,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":141,"y":156,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":141,"y":199,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":141,"y":242,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":141,"y":285,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":141,"y":328,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":141,"y":371,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":141,"y":29,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image234952":{"x":141,"y":72,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23414":{"x":141,"y":115,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23412":{"x":141,"y":158,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23410":{"x":141,"y":201,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23408":{"x":141,"y":244,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image232937":{"x":141,"y":287,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image233037":{"x":141,"y":330,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"text23343":{"x":141,"y":37,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":141,"y":80,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":141,"y":123,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":141,"y":166,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":141,"y":209,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":141,"y":252,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":141,"y":295,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":141,"y":338,"w":785,"h":31,"txtscale":100}
,
"button143478":{"x":274,"y":135,"w":141,"h":56,"stylemods":[{"sel":"div.button143478Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143478Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button143478.png","irol":"images/PhoneLandscape_button143478_over.png","ion":"images/PhoneLandscape_button143478_down.png","idis":"images/PhoneLandscape_button143478_disabled.png"}
,
"button143578":{"x":274,"y":190,"w":141,"h":56,"stylemods":[{"sel":"div.button143578Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143578Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button143578.png","irol":"images/PhoneLandscape_button143578_over.png","ion":"images/PhoneLandscape_button143578_down.png","idis":"images/PhoneLandscape_button143578_disabled.png"}
,
"button143597":{"x":274,"y":245,"w":141,"h":56,"stylemods":[{"sel":"div.button143597Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143597Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button143597.png","irol":"images/PhoneLandscape_button143597_over.png","ion":"images/PhoneLandscape_button143597_down.png","idis":"images/PhoneLandscape_button143597_disabled.png"}
,
"button143610":{"x":274,"y":300,"w":141,"h":56,"stylemods":[{"sel":"div.button143610Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143610Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button143610.png","irol":"images/PhoneLandscape_button143610_over.png","ion":"images/PhoneLandscape_button143610_down.png","idis":"images/PhoneLandscape_button143610_disabled.png"}
,
"shape141298":{"x":-70,"y":97,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape141298.png"}
,
"shape231677":{"x":-70,"y":143,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231677.png"}
,
"shape231747":{"x":-70,"y":190,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231747.png"}
,
"shape231826":{"x":-70,"y":237,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":787,"h":388,"i":"images/bg_voilet.png"}
,
"button21550":{"x":111,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21550.png","irol":"images/PhoneLandscape_button21550_over.png","ion":"images/PhoneLandscape_button21550_down.png","idis":"images/PhoneLandscape_button21550_disabled.png"}
,
"button21689":{"x":608,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21689.png","irol":"images/PhoneLandscape_button21689_over.png","ion":"images/PhoneLandscape_button21689_down.png","idis":"images/PhoneLandscape_button21689_disabled.png"}
,
"text38077":{"x":156,"y":13,"w":472,"h":34,"txtscale":100}
,
"shape365091":{"x":203,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365091.png"}
,
"shape365089":{"x":294,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365089.png"}
,
"shape365087":{"x":384,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365087.png"}
,
"shape365085":{"x":474,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365085.png"}
,
"shape366845":{"x":203,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366845.png"}
,
"shape366843":{"x":249,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366843.png"}
,
"shape366841":{"x":294,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366841.png"}
,
"text142747":{"x":156,"y":68,"w":472,"h":42,"txtscale":100}
,
"text142748":{"x":55,"y":138,"w":196,"h":208,"txtscale":100}
,
"image143318":{"x":278,"y":137,"w":137,"h":52,"i":"images/button.png"}
,
"text143100":{"x":278,"y":150,"w":137,"h":26,"txtscale":100}
,
"image143582":{"x":278,"y":192,"w":137,"h":52,"i":"images/button.png"}
,
"text143678":{"x":278,"y":205,"w":137,"h":26,"txtscale":100}
,
"image143591":{"x":278,"y":247,"w":137,"h":52,"i":"images/button.png"}
,
"text143592":{"x":278,"y":260,"w":137,"h":26,"txtscale":100}
,
"image143614":{"x":278,"y":302,"w":137,"h":52,"i":"images/button.png"}
,
"text143612":{"x":278,"y":315,"w":137,"h":26,"txtscale":100}
,
"image144950":{"x":441,"y":130,"w":320,"h":230,"i":"images/text_bg.png"}
,
"shape145044":{"x":418,"y":143,"w":29,"h":29,"stylemods":[{"sel":"div.shape145044Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145044Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape145044.png"}
,
"text142792":{"x":454,"y":145,"w":252,"h":29,"txtscale":100}
,
"text142793":{"x":454,"y":173,"w":292,"h":182,"txtscale":100}
,
"image145532":{"x":441,"y":130,"w":320,"h":230,"i":"images/text_bg.png"}
,
"shape145534":{"x":418,"y":202,"w":29,"h":29,"stylemods":[{"sel":"div.shape145534Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145534Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape145534.png"}
,
"text145535":{"x":455,"y":145,"w":252,"h":29,"txtscale":100}
,
"text145536":{"x":455,"y":173,"w":288,"h":182,"txtscale":100}
,
"image145615":{"x":441,"y":130,"w":320,"h":230,"i":"images/text_bg.png"}
,
"shape145617":{"x":418,"y":255,"w":29,"h":29,"stylemods":[{"sel":"div.shape145617Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145617Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape145617.png"}
,
"text145618":{"x":455,"y":145,"w":252,"h":29,"txtscale":100}
,
"text145619":{"x":455,"y":173,"w":262,"h":156,"txtscale":100}
,
"image145639":{"x":441,"y":130,"w":344,"h":258,"i":"images/text_bg.png"}
,
"shape145641":{"x":419,"y":311,"w":29,"h":29,"stylemods":[{"sel":"div.shape145641Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145641Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape145641.png"}
,
"text145642":{"x":455,"y":145,"w":252,"h":29,"txtscale":100}
,
"text145643":{"x":455,"y":173,"w":318,"h":208,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/button.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_button21550.png','images/PhoneLandscape_button21550_over.png','images/PhoneLandscape_button21550_down.png','images/PhoneLandscape_button21550_disabled.png','images/PhoneLandscape_button21689.png','images/PhoneLandscape_button21689_over.png','images/PhoneLandscape_button21689_down.png','images/PhoneLandscape_button21689_disabled.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_button143478.png','images/PhoneLandscape_button143478_over.png','images/PhoneLandscape_button143478_down.png','images/PhoneLandscape_button143478_disabled.png','images/PhoneLandscape_button143578.png','images/PhoneLandscape_button143578_over.png','images/PhoneLandscape_button143578_down.png','images/PhoneLandscape_button143578_disabled.png','images/PhoneLandscape_button143597.png','images/PhoneLandscape_button143597_over.png','images/PhoneLandscape_button143597_down.png','images/PhoneLandscape_button143597_disabled.png','images/PhoneLandscape_button143610.png','images/PhoneLandscape_button143610_over.png','images/PhoneLandscape_button143610_down.png','images/PhoneLandscape_button143610_disabled.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape145044.png','images/PhoneLandscape_shape145534.png','images/PhoneLandscape_shape145617.png','images/PhoneLandscape_shape145641.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"image38007":{"x":13,"y":14,"w":24,"h":23,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":483,"h":144,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:475px; height:136px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:475px; height:136px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape23327.png"}
,
"image23506":{"x":0,"y":141,"w":480,"h":622,"i":"images/menu_bg.png"}
,
"image23329":{"x":9,"y":10,"w":24,"h":34,"i":"images/menu_hide.png"}
,
"image23332":{"x":196,"y":31,"w":89,"h":79,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":205,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":260,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":315,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":370,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":425,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":480,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":534,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":588,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":151,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":206,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":261,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":316,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":371,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":426,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":480,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":534,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":165,"w":480,"h":26,"txtscale":100}
,
"text234944":{"x":0,"y":220,"w":480,"h":26,"txtscale":100}
,
"text23349":{"x":0,"y":275,"w":480,"h":26,"txtscale":100}
,
"text23352":{"x":0,"y":329,"w":480,"h":26,"txtscale":100}
,
"text23355":{"x":0,"y":386,"w":480,"h":26,"txtscale":100}
,
"text23358":{"x":0,"y":440,"w":480,"h":26,"txtscale":100}
,
"text232929":{"x":0,"y":494,"w":480,"h":26,"txtscale":100}
,
"text233029":{"x":0,"y":546,"w":480,"h":26,"txtscale":100}
,
"button143478":{"x":43,"y":307,"w":141,"h":56,"stylemods":[{"sel":"div.button143478Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143478Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button143478.png","irol":"images/PhonePortrait_button143478_over.png","ion":"images/PhonePortrait_button143478_down.png","idis":"images/PhonePortrait_button143478_disabled.png"}
,
"button143578":{"x":43,"y":382,"w":141,"h":56,"stylemods":[{"sel":"div.button143578Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143578Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button143578.png","irol":"images/PhonePortrait_button143578_over.png","ion":"images/PhonePortrait_button143578_down.png","idis":"images/PhonePortrait_button143578_disabled.png"}
,
"button143597":{"x":43,"y":456,"w":141,"h":56,"stylemods":[{"sel":"div.button143597Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143597Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button143597.png","irol":"images/PhonePortrait_button143597_over.png","ion":"images/PhonePortrait_button143597_down.png","idis":"images/PhonePortrait_button143597_disabled.png"}
,
"button143610":{"x":43,"y":531,"w":141,"h":56,"stylemods":[{"sel":"div.button143610Text","decl":" { position:absolute; left:4px; top:2px; width:129px; height:48px;}"},{"sel":"span.button143610Text","decl":" { display:table-cell; position:relative; width:129px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button143610.png","irol":"images/PhonePortrait_button143610_over.png","ion":"images/PhonePortrait_button143610_down.png","idis":"images/PhonePortrait_button143610_disabled.png"}
,
"shape141298":{"x":-43,"y":125,"w":27,"h":28,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape141298.png"}
,
"shape231677":{"x":-43,"y":185,"w":27,"h":28,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231677.png"}
,
"shape231747":{"x":-43,"y":245,"w":27,"h":28,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231747.png"}
,
"shape231826":{"x":-43,"y":305,"w":27,"h":28,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":481,"h":687,"i":"images/bg_voilet.png"}
,
"button21550":{"x":48,"y":696,"w":62,"h":58,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21550.png","irol":"images/PhonePortrait_button21550_over.png","ion":"images/PhonePortrait_button21550_down.png","idis":"images/PhonePortrait_button21550_disabled.png"}
,
"button21689":{"x":366,"y":695,"w":62,"h":58,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21689.png","irol":"images/PhonePortrait_button21689_over.png","ion":"images/PhonePortrait_button21689_down.png","idis":"images/PhonePortrait_button21689_disabled.png"}
,
"text38077":{"x":96,"y":14,"w":289,"h":33,"txtscale":100}
,
"shape365091":{"x":121,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365091.png"}
,
"shape365089":{"x":178,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365089.png"}
,
"shape365087":{"x":235,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365087.png"}
,
"shape365085":{"x":292,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365085.png"}
,
"shape366845":{"x":120,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366845.png"}
,
"shape366843":{"x":149,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366843.png"}
,
"shape366841":{"x":178,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366841.png"}
,
"text142747":{"x":54,"y":88,"w":373,"h":59,"txtscale":100}
,
"text142748":{"x":45,"y":149,"w":390,"h":138,"txtscale":100}
,
"image143318":{"x":47,"y":309,"w":137,"h":52,"i":"images/button.png"}
,
"text143100":{"x":48,"y":322,"w":135,"h":26,"txtscale":100}
,
"image143582":{"x":47,"y":384,"w":137,"h":52,"i":"images/button.png"}
,
"text143678":{"x":48,"y":397,"w":137,"h":26,"txtscale":100}
,
"image143591":{"x":47,"y":458,"w":137,"h":52,"i":"images/button.png"}
,
"text143592":{"x":48,"y":471,"w":137,"h":26,"txtscale":100}
,
"image143614":{"x":47,"y":533,"w":137,"h":52,"i":"images/button.png"}
,
"text143612":{"x":48,"y":546,"w":137,"h":26,"txtscale":100}
,
"image144950":{"x":206,"y":299,"w":262,"h":300,"i":"images/text_bg.png"}
,
"shape145044":{"x":185,"y":322,"w":29,"h":29,"stylemods":[{"sel":"div.shape145044Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145044Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape145044.png"}
,
"text142792":{"x":219,"y":316,"w":363,"h":31,"txtscale":100}
,
"text142793":{"x":219,"y":344,"w":240,"h":208,"txtscale":100}
,
"image145532":{"x":206,"y":299,"w":262,"h":300,"i":"images/text_bg.png"}
,
"shape145534":{"x":185,"y":398,"w":29,"h":29,"stylemods":[{"sel":"div.shape145534Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145534Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape145534.png"}
,
"text145535":{"x":219,"y":316,"w":363,"h":31,"txtscale":100}
,
"text145536":{"x":219,"y":344,"w":234,"h":208,"txtscale":100}
,
"image145615":{"x":206,"y":299,"w":262,"h":300,"i":"images/text_bg.png"}
,
"shape145617":{"x":185,"y":471,"w":29,"h":29,"stylemods":[{"sel":"div.shape145617Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145617Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape145617.png"}
,
"text145618":{"x":219,"y":316,"w":363,"h":31,"txtscale":100}
,
"text145619":{"x":219,"y":344,"w":233,"h":156,"txtscale":100}
,
"image145639":{"x":206,"y":299,"w":262,"h":350,"i":"images/text_bg.png"}
,
"shape145641":{"x":185,"y":545,"w":29,"h":29,"stylemods":[{"sel":"div.shape145641Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape145641Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape145641.png"}
,
"text145642":{"x":219,"y":316,"w":237,"h":31,"txtscale":100}
,
"text145643":{"x":219,"y":344,"w":237,"h":286,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/button.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_button21550.png','images/PhonePortrait_button21550_over.png','images/PhonePortrait_button21550_down.png','images/PhonePortrait_button21550_disabled.png','images/PhonePortrait_button21689.png','images/PhonePortrait_button21689_over.png','images/PhonePortrait_button21689_down.png','images/PhonePortrait_button21689_disabled.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_button143478.png','images/PhonePortrait_button143478_over.png','images/PhonePortrait_button143478_down.png','images/PhonePortrait_button143478_disabled.png','images/PhonePortrait_button143578.png','images/PhonePortrait_button143578_over.png','images/PhonePortrait_button143578_down.png','images/PhonePortrait_button143578_disabled.png','images/PhonePortrait_button143597.png','images/PhonePortrait_button143597_over.png','images/PhonePortrait_button143597_down.png','images/PhonePortrait_button143597_disabled.png','images/PhonePortrait_button143610.png','images/PhonePortrait_button143610_over.png','images/PhonePortrait_button143610_down.png','images/PhonePortrait_button143610_disabled.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape145044.png','images/PhonePortrait_shape145534.png','images/PhonePortrait_shape145617.png','images/PhonePortrait_shape145641.png']
}}
