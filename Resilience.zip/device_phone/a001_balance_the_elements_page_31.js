PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"image38007":{"x":14,"y":11,"w":30,"h":27,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":139,"y":-56,"w":790,"h":90,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:782px; height:82px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:782px; height:82px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape23327.png"}
,
"image23506":{"x":141,"y":24,"w":785,"h":372,"i":"images/menu_bg.png"}
,
"image23329":{"x":156,"y":-47,"w":20,"h":29,"i":"images/menu_hide.png"}
,
"image23332":{"x":497,"y":-46,"w":72,"h":63,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":141,"y":70,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":141,"y":113,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":141,"y":156,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":141,"y":199,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":141,"y":242,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":141,"y":285,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":141,"y":328,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":141,"y":371,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":141,"y":29,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image234952":{"x":141,"y":72,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23414":{"x":141,"y":115,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23412":{"x":141,"y":158,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23410":{"x":141,"y":201,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23408":{"x":141,"y":244,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image232937":{"x":141,"y":287,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image233037":{"x":141,"y":330,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"text23343":{"x":141,"y":37,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":141,"y":80,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":141,"y":123,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":141,"y":166,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":141,"y":209,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":141,"y":252,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":141,"y":295,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":141,"y":338,"w":785,"h":31,"txtscale":100}
,
"button340044":{"x":322,"y":120,"w":128,"h":108,"stylemods":[{"sel":"div.button340044Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button340044Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button340044.png","irol":"images/PhoneLandscape_button340044_over.png","ion":"images/PhoneLandscape_button340044_down.png","idis":"images/PhoneLandscape_button340044_disabled.png"}
,
"button341307":{"x":486,"y":121,"w":128,"h":108,"stylemods":[{"sel":"div.button341307Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button341307Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button341307.png","irol":"images/PhoneLandscape_button341307_over.png","ion":"images/PhoneLandscape_button341307_down.png","idis":"images/PhoneLandscape_button341307_disabled.png"}
,
"button341988":{"x":649,"y":120,"w":128,"h":108,"stylemods":[{"sel":"div.button341988Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button341988Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button341988.png","irol":"images/PhoneLandscape_button341988_over.png","ion":"images/PhoneLandscape_button341988_down.png","idis":"images/PhoneLandscape_button341988_disabled.png"}
,
"button342527":{"x":322,"y":263,"w":128,"h":108,"stylemods":[{"sel":"div.button342527Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button342527Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button342527.png","irol":"images/PhoneLandscape_button342527_over.png","ion":"images/PhoneLandscape_button342527_down.png","idis":"images/PhoneLandscape_button342527_disabled.png"}
,
"button343995":{"x":487,"y":261,"w":128,"h":108,"stylemods":[{"sel":"div.button343995Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button343995Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button343995.png","irol":"images/PhoneLandscape_button343995_over.png","ion":"images/PhoneLandscape_button343995_down.png","idis":"images/PhoneLandscape_button343995_disabled.png"}
,
"shape141298":{"x":-70,"y":97,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape141298.png"}
,
"shape231677":{"x":-70,"y":143,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231677.png"}
,
"shape231747":{"x":-70,"y":190,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231747.png"}
,
"shape231826":{"x":-70,"y":237,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":787,"h":388,"i":"images/bg_voilet.png"}
,
"button21550":{"x":111,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21550.png","irol":"images/PhoneLandscape_button21550_over.png","ion":"images/PhoneLandscape_button21550_down.png","idis":"images/PhoneLandscape_button21550_disabled.png"}
,
"button21689":{"x":608,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21689.png","irol":"images/PhoneLandscape_button21689_over.png","ion":"images/PhoneLandscape_button21689_down.png","idis":"images/PhoneLandscape_button21689_disabled.png"}
,
"text38077":{"x":156,"y":13,"w":472,"h":34,"txtscale":100}
,
"shape365091":{"x":203,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365091.png"}
,
"shape365089":{"x":294,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365089.png"}
,
"shape365087":{"x":384,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365087.png"}
,
"shape365085":{"x":474,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365085.png"}
,
"shape366800":{"x":203,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366800Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366800Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366800.png"}
,
"shape366798":{"x":249,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366798Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366798Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366798.png"}
,
"shape366796":{"x":294,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366796Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366796Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366796.png"}
,
"shape366794":{"x":339,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366794Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366794Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366794.png"}
,
"image159408":{"x":490,"y":260,"w":125,"h":108,"i":"images/get_physical.png"}
,
"image159323":{"x":326,"y":260,"w":125,"h":111,"i":"images/feed_the_engine.png"}
,
"image159268":{"x":652,"y":119,"w":125,"h":108,"i":"images/me_time.png"}
,
"image159215":{"x":489,"y":119,"w":125,"h":111,"i":"images/switch_off.png"}
,
"image158808":{"x":326,"y":119,"w":125,"h":115,"i":"images/talk_it_out.png"}
,
"text335950":{"x":490,"y":270,"w":118,"h":29,"txtscale":100}
,
"text338454":{"x":338,"y":267,"w":99,"h":52,"txtscale":100}
,
"text337162":{"x":665,"y":129,"w":99,"h":28,"txtscale":100}
,
"text336739":{"x":502,"y":132,"w":99,"h":28,"txtscale":100}
,
"text336158":{"x":339,"y":130,"w":99,"h":28,"txtscale":100}
,
"image158965":{"x":288,"y":146,"w":33,"h":29,"i":"images/uncheck.png"}
,
"image159060":{"x":294,"y":138,"w":33,"h":29,"i":"images/check.png"}
,
"image159540":{"x":453,"y":146,"w":33,"h":29,"i":"images/uncheck.png"}
,
"image159537":{"x":459,"y":138,"w":33,"h":29,"i":"images/check.png"}
,
"image159734":{"x":615,"y":146,"w":33,"h":29,"i":"images/uncheck.png"}
,
"image159731":{"x":621,"y":138,"w":33,"h":29,"i":"images/check.png"}
,
"image159915":{"x":289,"y":287,"w":33,"h":29,"i":"images/uncheck.png"}
,
"image159918":{"x":295,"y":279,"w":33,"h":29,"i":"images/check.png"}
,
"image160305":{"x":453,"y":287,"w":33,"h":29,"i":"images/uncheck.png"}
,
"image160308":{"x":459,"y":279,"w":33,"h":29,"i":"images/check.png"}
,
"image88525":{"x":11,"y":118,"w":273,"h":245,"i":"images/text_bg.png"}
,
"text88526":{"x":156,"y":68,"w":472,"h":42,"txtscale":100}
,
"text88527":{"x":36,"y":138,"w":224,"h":208,"txtscale":100}
,
"image166079":{"x":14,"y":121,"w":272,"h":236,"i":"images/text_bg.png"}
,
"shape166081":{"x":21,"y":149,"w":29,"h":29,"stylemods":[{"sel":"div.shape166081Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape166081Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape166081.png"}
,
"text166082":{"x":27,"y":136,"w":252,"h":29,"txtscale":100}
,
"text166083":{"x":27,"y":164,"w":242,"h":156,"txtscale":100}
,
"image166497":{"x":12,"y":118,"w":275,"h":268,"i":"images/text_bg.png"}
,
"shape166499":{"x":193,"y":152,"w":29,"h":29,"stylemods":[{"sel":"div.shape166499Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape166499Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape166499.png"}
,
"text166500":{"x":27,"y":133,"w":162,"h":29,"txtscale":100}
,
"text166501":{"x":27,"y":161,"w":248,"h":208,"txtscale":100}
,
"image168771":{"x":10,"y":119,"w":279,"h":265,"i":"images/text_bg.png"}
,
"shape168773":{"x":27,"y":147,"w":29,"h":29,"stylemods":[{"sel":"div.shape168773Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape168773Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape168773.png"}
,
"text168774":{"x":23,"y":134,"w":252,"h":29,"txtscale":100}
,
"text168775":{"x":23,"y":162,"w":253,"h":208,"txtscale":100}
,
"image169543":{"x":10,"y":120,"w":279,"h":265,"i":"images/text_bg.png"}
,
"shape169545":{"x":21,"y":241,"w":29,"h":29,"stylemods":[{"sel":"div.shape169545Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape169545Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape169545.png"}
,
"text169546":{"x":23,"y":135,"w":252,"h":29,"txtscale":100}
,
"text169547":{"x":23,"y":163,"w":246,"h":182,"txtscale":100}
,
"image170139":{"x":10,"y":121,"w":279,"h":263,"i":"images/text_bg.png"}
,
"shape170141":{"x":21,"y":242,"w":29,"h":29,"stylemods":[{"sel":"div.shape170141Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape170141Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape170141.png"}
,
"text170142":{"x":23,"y":136,"w":252,"h":29,"txtscale":100}
,
"text170143":{"x":23,"y":164,"w":242,"h":156,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/talk_it_out.png','images/uncheck.png','images/check.png','images/switch_off.png','images/me_time.png','images/feed_the_engine.png','images/get_physical.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_button21550.png','images/PhoneLandscape_button21550_over.png','images/PhoneLandscape_button21550_down.png','images/PhoneLandscape_button21550_disabled.png','images/PhoneLandscape_button21689.png','images/PhoneLandscape_button21689_over.png','images/PhoneLandscape_button21689_down.png','images/PhoneLandscape_button21689_disabled.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_button340044.png','images/PhoneLandscape_button340044_over.png','images/PhoneLandscape_button340044_down.png','images/PhoneLandscape_button340044_disabled.png','images/PhoneLandscape_button341307.png','images/PhoneLandscape_button341307_over.png','images/PhoneLandscape_button341307_down.png','images/PhoneLandscape_button341307_disabled.png','images/PhoneLandscape_button341988.png','images/PhoneLandscape_button341988_over.png','images/PhoneLandscape_button341988_down.png','images/PhoneLandscape_button341988_disabled.png','images/PhoneLandscape_button342527.png','images/PhoneLandscape_button342527_over.png','images/PhoneLandscape_button342527_down.png','images/PhoneLandscape_button342527_disabled.png','images/PhoneLandscape_button343995.png','images/PhoneLandscape_button343995_over.png','images/PhoneLandscape_button343995_down.png','images/PhoneLandscape_button343995_disabled.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape166081.png','images/PhoneLandscape_shape166499.png','images/PhoneLandscape_shape168773.png','images/PhoneLandscape_shape169545.png','images/PhoneLandscape_shape170141.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"image38007":{"x":13,"y":14,"w":24,"h":23,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":483,"h":144,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:475px; height:136px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:475px; height:136px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape23327.png"}
,
"image23506":{"x":0,"y":141,"w":480,"h":622,"i":"images/menu_bg.png"}
,
"image23329":{"x":9,"y":10,"w":24,"h":34,"i":"images/menu_hide.png"}
,
"image23332":{"x":196,"y":31,"w":89,"h":79,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":205,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":260,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":315,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":370,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":425,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":480,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":534,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":588,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":151,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":206,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":261,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":316,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":371,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":426,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":480,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":534,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":165,"w":480,"h":26,"txtscale":100}
,
"text234944":{"x":0,"y":220,"w":480,"h":26,"txtscale":100}
,
"text23349":{"x":0,"y":275,"w":480,"h":26,"txtscale":100}
,
"text23352":{"x":0,"y":329,"w":480,"h":26,"txtscale":100}
,
"text23355":{"x":0,"y":386,"w":480,"h":26,"txtscale":100}
,
"text23358":{"x":0,"y":440,"w":480,"h":26,"txtscale":100}
,
"text232929":{"x":0,"y":494,"w":480,"h":26,"txtscale":100}
,
"text233029":{"x":0,"y":546,"w":480,"h":26,"txtscale":100}
,
"button340044":{"x":104,"y":312,"w":128,"h":108,"stylemods":[{"sel":"div.button340044Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button340044Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button340044.png","irol":"images/PhonePortrait_button340044_over.png","ion":"images/PhonePortrait_button340044_down.png","idis":"images/PhonePortrait_button340044_disabled.png"}
,
"button341307":{"x":313,"y":316,"w":128,"h":108,"stylemods":[{"sel":"div.button341307Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button341307Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button341307.png","irol":"images/PhonePortrait_button341307_over.png","ion":"images/PhonePortrait_button341307_down.png","idis":"images/PhonePortrait_button341307_disabled.png"}
,
"button341988":{"x":103,"y":431,"w":128,"h":108,"stylemods":[{"sel":"div.button341988Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button341988Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button341988.png","irol":"images/PhonePortrait_button341988_over.png","ion":"images/PhonePortrait_button341988_down.png","idis":"images/PhonePortrait_button341988_disabled.png"}
,
"button342527":{"x":313,"y":436,"w":128,"h":108,"stylemods":[{"sel":"div.button342527Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button342527Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button342527.png","irol":"images/PhonePortrait_button342527_over.png","ion":"images/PhonePortrait_button342527_down.png","idis":"images/PhonePortrait_button342527_disabled.png"}
,
"button343995":{"x":102,"y":550,"w":128,"h":108,"stylemods":[{"sel":"div.button343995Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button343995Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button343995.png","irol":"images/PhonePortrait_button343995_over.png","ion":"images/PhonePortrait_button343995_down.png","idis":"images/PhonePortrait_button343995_disabled.png"}
,
"shape141298":{"x":-43,"y":125,"w":27,"h":28,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape141298.png"}
,
"shape231677":{"x":-43,"y":185,"w":27,"h":28,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231677.png"}
,
"shape231747":{"x":-43,"y":245,"w":27,"h":28,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231747.png"}
,
"shape231826":{"x":-43,"y":305,"w":27,"h":28,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":481,"h":687,"i":"images/bg_voilet.png"}
,
"button21550":{"x":48,"y":696,"w":62,"h":58,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21550.png","irol":"images/PhonePortrait_button21550_over.png","ion":"images/PhonePortrait_button21550_down.png","idis":"images/PhonePortrait_button21550_disabled.png"}
,
"button21689":{"x":366,"y":695,"w":62,"h":58,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21689.png","irol":"images/PhonePortrait_button21689_over.png","ion":"images/PhonePortrait_button21689_down.png","idis":"images/PhonePortrait_button21689_disabled.png"}
,
"text38077":{"x":96,"y":14,"w":289,"h":33,"txtscale":100}
,
"shape365091":{"x":121,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365091.png"}
,
"shape365089":{"x":178,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365089.png"}
,
"shape365087":{"x":235,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365087.png"}
,
"shape365085":{"x":292,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365085.png"}
,
"shape366800":{"x":120,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366800Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366800Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366800.png"}
,
"shape366798":{"x":149,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366798Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366798Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366798.png"}
,
"shape366796":{"x":178,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366796Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366796Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366796.png"}
,
"shape366794":{"x":206,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366794Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366794Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366794.png"}
,
"image159408":{"x":106,"y":550,"w":125,"h":108,"i":"images/get_physical.png"}
,
"image159323":{"x":316,"y":434,"w":125,"h":110,"i":"images/feed_the_engine.png"}
,
"image159268":{"x":107,"y":431,"w":125,"h":108,"i":"images/me_time.png"}
,
"image159215":{"x":316,"y":315,"w":125,"h":110,"i":"images/switch_off.png"}
,
"image158808":{"x":108,"y":312,"w":125,"h":114,"i":"images/talk_it_out.png"}
,
"text335950":{"x":111,"y":560,"w":107,"h":27,"txtscale":100}
,
"text338454":{"x":325,"y":440,"w":107,"h":53,"txtscale":100}
,
"text337162":{"x":116,"y":441,"w":107,"h":30,"txtscale":100}
,
"text336739":{"x":325,"y":326,"w":107,"h":30,"txtscale":100}
,
"text336158":{"x":117,"y":323,"w":107,"h":30,"txtscale":100}
,
"image158965":{"x":55,"y":353,"w":33,"h":28,"i":"images/uncheck.png"}
,
"image159060":{"x":62,"y":345,"w":33,"h":28,"i":"images/check.png"}
,
"image159540":{"x":262,"y":353,"w":33,"h":28,"i":"images/uncheck.png"}
,
"image159537":{"x":269,"y":345,"w":33,"h":28,"i":"images/check.png"}
,
"image159734":{"x":55,"y":472,"w":33,"h":28,"i":"images/uncheck.png"}
,
"image159731":{"x":62,"y":464,"w":33,"h":28,"i":"images/check.png"}
,
"image159915":{"x":262,"y":472,"w":33,"h":28,"i":"images/uncheck.png"}
,
"image159918":{"x":269,"y":464,"w":33,"h":28,"i":"images/check.png"}
,
"image160305":{"x":54,"y":591,"w":33,"h":28,"i":"images/uncheck.png"}
,
"image160308":{"x":61,"y":583,"w":33,"h":28,"i":"images/check.png"}
,
"image88525":{"x":12,"y":150,"w":460,"h":158,"i":"images/text_bg.png"}
,
"text88526":{"x":54,"y":88,"w":373,"h":59,"txtscale":100}
,
"text88527":{"x":34,"y":174,"w":412,"h":114,"txtscale":100}
,
"image166079":{"x":241,"y":318,"w":227,"h":248,"i":"images/text_bg.png"}
,
"shape166081":{"x":249,"y":356,"w":29,"h":29,"stylemods":[{"sel":"div.shape166081Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape166081Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape166081.png"}
,
"text166082":{"x":254,"y":335,"w":212,"h":31,"txtscale":100}
,
"text166083":{"x":254,"y":363,"w":203,"h":182,"txtscale":100}
,
"image166497":{"x":236,"y":384,"w":236,"h":300,"i":"images/text_bg.png"}
,
"shape166499":{"x":245,"y":477,"w":29,"h":29,"stylemods":[{"sel":"div.shape166499Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape166499Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape166499.png"}
,
"text166500":{"x":249,"y":401,"w":210,"h":31,"txtscale":100}
,
"text166501":{"x":249,"y":429,"w":208,"h":260,"txtscale":100}
,
"image168771":{"x":16,"y":318,"w":296,"h":254,"i":"images/text_bg.png"}
,
"shape168773":{"x":18,"y":356,"w":29,"h":29,"stylemods":[{"sel":"div.shape168773Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape168773Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape168773.png"}
,
"text168774":{"x":29,"y":335,"w":212,"h":31,"txtscale":100}
,
"text168775":{"x":29,"y":363,"w":266,"h":194,"txtscale":100}
,
"image169543":{"x":15,"y":366,"w":299,"h":255,"i":"images/text_bg.png"}
,
"shape169545":{"x":22,"y":404,"w":29,"h":29,"stylemods":[{"sel":"div.shape169545Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape169545Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape169545.png"}
,
"text169546":{"x":28,"y":383,"w":212,"h":31,"txtscale":100}
,
"text169547":{"x":28,"y":411,"w":270,"h":190,"txtscale":100}
,
"image170139":{"x":15,"y":346,"w":299,"h":204,"i":"images/text_bg.png"}
,
"shape170141":{"x":22,"y":384,"w":29,"h":29,"stylemods":[{"sel":"div.shape170141Text","decl":" { position:absolute; left:2px; top:2px; width:21px; height:21px;}"},{"sel":"span.shape170141Text","decl":" { display:table-cell; position:relative; width:21px; height:21px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape170141.png"}
,
"text170142":{"x":28,"y":363,"w":212,"h":31,"txtscale":100}
,
"text170143":{"x":28,"y":391,"w":270,"h":146,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/talk_it_out.png','images/uncheck.png','images/check.png','images/switch_off.png','images/me_time.png','images/feed_the_engine.png','images/get_physical.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_button21550.png','images/PhonePortrait_button21550_over.png','images/PhonePortrait_button21550_down.png','images/PhonePortrait_button21550_disabled.png','images/PhonePortrait_button21689.png','images/PhonePortrait_button21689_over.png','images/PhonePortrait_button21689_down.png','images/PhonePortrait_button21689_disabled.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_button340044.png','images/PhonePortrait_button340044_over.png','images/PhonePortrait_button340044_down.png','images/PhonePortrait_button340044_disabled.png','images/PhonePortrait_button341307.png','images/PhonePortrait_button341307_over.png','images/PhonePortrait_button341307_down.png','images/PhonePortrait_button341307_disabled.png','images/PhonePortrait_button341988.png','images/PhonePortrait_button341988_over.png','images/PhonePortrait_button341988_down.png','images/PhonePortrait_button341988_disabled.png','images/PhonePortrait_button342527.png','images/PhonePortrait_button342527_over.png','images/PhonePortrait_button342527_down.png','images/PhonePortrait_button342527_disabled.png','images/PhonePortrait_button343995.png','images/PhonePortrait_button343995_over.png','images/PhonePortrait_button343995_down.png','images/PhonePortrait_button343995_disabled.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape166081.png','images/PhonePortrait_shape166499.png','images/PhonePortrait_shape168773.png','images/PhonePortrait_shape169545.png','images/PhonePortrait_shape170141.png']
}}
