PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"image38007":{"x":14,"y":11,"w":30,"h":27,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":139,"y":-56,"w":790,"h":90,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:782px; height:82px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:782px; height:82px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape23327.png"}
,
"image23506":{"x":141,"y":24,"w":785,"h":372,"i":"images/menu_bg.png"}
,
"image23329":{"x":156,"y":-47,"w":20,"h":29,"i":"images/menu_hide.png"}
,
"image23332":{"x":497,"y":-46,"w":72,"h":63,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":141,"y":70,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":141,"y":113,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":141,"y":156,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":141,"y":199,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":141,"y":242,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":141,"y":285,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":141,"y":328,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":141,"y":371,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":141,"y":29,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image234952":{"x":141,"y":72,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23414":{"x":141,"y":115,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23412":{"x":141,"y":158,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23410":{"x":141,"y":201,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23408":{"x":141,"y":244,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image232937":{"x":141,"y":287,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image233037":{"x":141,"y":330,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"text23343":{"x":141,"y":37,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":141,"y":80,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":141,"y":123,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":141,"y":166,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":141,"y":209,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":141,"y":252,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":141,"y":295,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":141,"y":338,"w":785,"h":31,"txtscale":100}
,
"button278429":{"x":563,"y":113,"w":135,"h":55,"stylemods":[{"sel":"div.button278429Text","decl":" { position:absolute; left:5px; top:2px; width:121px; height:47px;}"},{"sel":"span.button278429Text","decl":" { display:table-cell; position:relative; width:121px; height:47px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278429.png","irol":"images/PhoneLandscape_button278429_over.png","ion":"images/PhoneLandscape_button278429_down.png","idis":"images/PhoneLandscape_button278429_disabled.png"}
,
"button278440":{"x":255,"y":207,"w":49,"h":44,"stylemods":[{"sel":"div.button278440Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278440Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278440.png","irol":"images/PhoneLandscape_button278440_over.png","ion":"images/PhoneLandscape_button278440_down.png","idis":"images/PhoneLandscape_button278440_disabled.png"}
,
"button278447":{"x":326,"y":206,"w":49,"h":44,"stylemods":[{"sel":"div.button278447Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278447Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278447.png","irol":"images/PhoneLandscape_button278447_over.png","ion":"images/PhoneLandscape_button278447_down.png","idis":"images/PhoneLandscape_button278447_disabled.png"}
,
"button278454":{"x":256,"y":251,"w":49,"h":44,"stylemods":[{"sel":"div.button278454Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278454Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278454.png","irol":"images/PhoneLandscape_button278454_over.png","ion":"images/PhoneLandscape_button278454_down.png","idis":"images/PhoneLandscape_button278454_disabled.png"}
,
"button278461":{"x":326,"y":251,"w":49,"h":44,"stylemods":[{"sel":"div.button278461Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278461Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278461.png","irol":"images/PhoneLandscape_button278461_over.png","ion":"images/PhoneLandscape_button278461_down.png","idis":"images/PhoneLandscape_button278461_disabled.png"}
,
"button278468":{"x":257,"y":295,"w":49,"h":44,"stylemods":[{"sel":"div.button278468Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278468Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278468.png","irol":"images/PhoneLandscape_button278468_over.png","ion":"images/PhoneLandscape_button278468_down.png","idis":"images/PhoneLandscape_button278468_disabled.png"}
,
"button278475":{"x":327,"y":297,"w":49,"h":44,"stylemods":[{"sel":"div.button278475Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278475Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278475.png","irol":"images/PhoneLandscape_button278475_over.png","ion":"images/PhoneLandscape_button278475_down.png","idis":"images/PhoneLandscape_button278475_disabled.png"}
,
"button278482":{"x":587,"y":211,"w":49,"h":44,"stylemods":[{"sel":"div.button278482Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278482Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278482.png","irol":"images/PhoneLandscape_button278482_over.png","ion":"images/PhoneLandscape_button278482_down.png","idis":"images/PhoneLandscape_button278482_disabled.png"}
,
"button278489":{"x":657,"y":211,"w":49,"h":44,"stylemods":[{"sel":"div.button278489Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278489Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278489.png","irol":"images/PhoneLandscape_button278489_over.png","ion":"images/PhoneLandscape_button278489_down.png","idis":"images/PhoneLandscape_button278489_disabled.png"}
,
"button278879":{"x":587,"y":255,"w":49,"h":44,"stylemods":[{"sel":"div.button278879Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278879Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278879.png","irol":"images/PhoneLandscape_button278879_over.png","ion":"images/PhoneLandscape_button278879_down.png","idis":"images/PhoneLandscape_button278879_disabled.png"}
,
"button278872":{"x":657,"y":255,"w":49,"h":44,"stylemods":[{"sel":"div.button278872Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278872Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278872.png","irol":"images/PhoneLandscape_button278872_over.png","ion":"images/PhoneLandscape_button278872_down.png","idis":"images/PhoneLandscape_button278872_disabled.png"}
,
"shape141298":{"x":-70,"y":97,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape141298.png"}
,
"shape231677":{"x":-70,"y":143,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231677.png"}
,
"shape231747":{"x":-70,"y":190,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231747.png"}
,
"shape231826":{"x":-70,"y":237,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":787,"h":388,"i":"images/bg_voilet.png"}
,
"button21550":{"x":111,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21550.png","irol":"images/PhoneLandscape_button21550_over.png","ion":"images/PhoneLandscape_button21550_down.png","idis":"images/PhoneLandscape_button21550_disabled.png"}
,
"button21689":{"x":608,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21689.png","irol":"images/PhoneLandscape_button21689_over.png","ion":"images/PhoneLandscape_button21689_down.png","idis":"images/PhoneLandscape_button21689_disabled.png"}
,
"text38077":{"x":156,"y":13,"w":472,"h":34,"txtscale":100}
,
"shape365091":{"x":203,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365091.png"}
,
"shape365089":{"x":294,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365089.png"}
,
"shape365087":{"x":384,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365087.png"}
,
"shape365085":{"x":474,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365085.png"}
,
"shape366845":{"x":203,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366845.png"}
,
"shape366843":{"x":249,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366843.png"}
,
"shape366841":{"x":294,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366841.png"}
,
"image278373":{"x":53,"y":50,"w":679,"h":342,"i":"images/text_bg.png"}
,
"text278374":{"x":156,"y":68,"w":472,"h":42,"txtscale":100}
,
"text278375":{"x":80,"y":108,"w":469,"h":55,"txtscale":100}
,
"text278376":{"x":81,"y":159,"w":237,"h":30,"txtscale":100}
,
"text278377":{"x":81,"y":192,"w":197,"h":27,"txtscale":100}
,
"text278378":{"x":81,"y":222,"w":271,"h":29,"txtscale":100}
,
"text278379":{"x":81,"y":263,"w":222,"h":31,"txtscale":100}
,
"text278380":{"x":81,"y":306,"w":207,"h":27,"txtscale":100}
,
"text278381":{"x":411,"y":218,"w":209,"h":27,"txtscale":100}
,
"text278892":{"x":411,"y":262,"w":209,"h":27,"txtscale":100}
,
"image278383":{"x":567,"y":113,"w":132,"h":54,"i":"images/remind_me.png"}
,
"text278384":{"x":607,"y":120,"w":88,"h":52,"txtscale":100}
,
"image278386":{"x":261,"y":210,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278388":{"x":259,"y":206,"w":47,"h":44,"i":"images/selected.png"}
,
"image278390":{"x":331,"y":210,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278392":{"x":329,"y":206,"w":47,"h":44,"i":"images/selected.png"}
,
"image278394":{"x":261,"y":253,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278396":{"x":259,"y":251,"w":47,"h":44,"i":"images/selected.png"}
,
"image278398":{"x":331,"y":253,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278400":{"x":329,"y":251,"w":47,"h":44,"i":"images/selected.png"}
,
"image278402":{"x":261,"y":297,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278404":{"x":260,"y":296,"w":47,"h":44,"i":"images/selected.png"}
,
"image278406":{"x":331,"y":297,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278408":{"x":330,"y":296,"w":47,"h":44,"i":"images/selected.png"}
,
"image278410":{"x":591,"y":212,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278412":{"x":590,"y":211,"w":47,"h":44,"i":"images/selected.png"}
,
"image278414":{"x":661,"y":212,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278416":{"x":660,"y":211,"w":47,"h":44,"i":"images/selected.png"}
,
"image278891":{"x":591,"y":256,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278889":{"x":590,"y":255,"w":47,"h":44,"i":"images/selected.png"}
,
"image278887":{"x":661,"y":256,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278885":{"x":660,"y":255,"w":47,"h":44,"i":"images/selected.png"}
,
"text278417":{"x":266,"y":220,"w":38,"h":24,"txtscale":100}
,
"text278418":{"x":335,"y":220,"w":38,"h":24,"txtscale":100}
,
"text278419":{"x":335,"y":263,"w":38,"h":24,"txtscale":100}
,
"text278420":{"x":266,"y":307,"w":38,"h":24,"txtscale":100}
,
"text278421":{"x":665,"y":221,"w":38,"h":24,"txtscale":100}
,
"text278422":{"x":596,"y":221,"w":38,"h":24,"txtscale":100}
,
"text278423":{"x":335,"y":307,"w":38,"h":24,"txtscale":100}
,
"text278424":{"x":266,"y":263,"w":38,"h":24,"txtscale":100}
,
"text278882":{"x":596,"y":265,"w":38,"h":24,"txtscale":100}
,
"text278883":{"x":665,"y":265,"w":38,"h":24,"txtscale":100}
,
"shape278500":{"x":107,"y":115,"w":449,"h":216,"stylemods":[{"sel":"div.shape278500Text","decl":" { position:absolute; left:4px; top:2px; width:437px; height:208px;}"},{"sel":"span.shape278500Text","decl":" { display:table-cell; position:relative; width:437px; height:208px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape278500.png"}
,
"text278501":{"x":138,"y":124,"w":405,"h":36,"txtscale":100}
,
"text278502":{"x":138,"y":164,"w":405,"h":36,"txtscale":100}
,
"text278503":{"x":138,"y":203,"w":405,"h":36,"txtscale":100}
,
"text278504":{"x":138,"y":243,"w":405,"h":36,"txtscale":100}
,
"text278505":{"x":138,"y":283,"w":405,"h":36,"txtscale":100}
,
"text324690":{"x":110,"y":124,"w":26,"h":26,"txtscale":100}
,
"text324689":{"x":110,"y":164,"w":26,"h":26,"txtscale":100}
,
"text324688":{"x":110,"y":203,"w":26,"h":26,"txtscale":100}
,
"text324687":{"x":110,"y":243,"w":26,"h":26,"txtscale":100}
,
"text324686":{"x":110,"y":283,"w":26,"h":26,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/remind_me.png','images/yes_n_no.png','images/selected.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_button21550.png','images/PhoneLandscape_button21550_over.png','images/PhoneLandscape_button21550_down.png','images/PhoneLandscape_button21550_disabled.png','images/PhoneLandscape_button21689.png','images/PhoneLandscape_button21689_over.png','images/PhoneLandscape_button21689_down.png','images/PhoneLandscape_button21689_disabled.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_button278429.png','images/PhoneLandscape_button278429_over.png','images/PhoneLandscape_button278429_down.png','images/PhoneLandscape_button278429_disabled.png','images/PhoneLandscape_button278440.png','images/PhoneLandscape_button278440_over.png','images/PhoneLandscape_button278440_down.png','images/PhoneLandscape_button278440_disabled.png','images/PhoneLandscape_button278447.png','images/PhoneLandscape_button278447_over.png','images/PhoneLandscape_button278447_down.png','images/PhoneLandscape_button278447_disabled.png','images/PhoneLandscape_button278454.png','images/PhoneLandscape_button278454_over.png','images/PhoneLandscape_button278454_down.png','images/PhoneLandscape_button278454_disabled.png','images/PhoneLandscape_button278461.png','images/PhoneLandscape_button278461_over.png','images/PhoneLandscape_button278461_down.png','images/PhoneLandscape_button278461_disabled.png','images/PhoneLandscape_button278468.png','images/PhoneLandscape_button278468_over.png','images/PhoneLandscape_button278468_down.png','images/PhoneLandscape_button278468_disabled.png','images/PhoneLandscape_button278475.png','images/PhoneLandscape_button278475_over.png','images/PhoneLandscape_button278475_down.png','images/PhoneLandscape_button278475_disabled.png','images/PhoneLandscape_button278482.png','images/PhoneLandscape_button278482_over.png','images/PhoneLandscape_button278482_down.png','images/PhoneLandscape_button278482_disabled.png','images/PhoneLandscape_button278489.png','images/PhoneLandscape_button278489_over.png','images/PhoneLandscape_button278489_down.png','images/PhoneLandscape_button278489_disabled.png','images/PhoneLandscape_button278879.png','images/PhoneLandscape_button278879_over.png','images/PhoneLandscape_button278879_down.png','images/PhoneLandscape_button278879_disabled.png','images/PhoneLandscape_button278872.png','images/PhoneLandscape_button278872_over.png','images/PhoneLandscape_button278872_down.png','images/PhoneLandscape_button278872_disabled.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape278500.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"image38007":{"x":13,"y":14,"w":24,"h":23,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":483,"h":144,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:475px; height:136px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:475px; height:136px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape23327.png"}
,
"image23506":{"x":0,"y":141,"w":480,"h":622,"i":"images/menu_bg.png"}
,
"image23329":{"x":9,"y":10,"w":24,"h":34,"i":"images/menu_hide.png"}
,
"image23332":{"x":196,"y":31,"w":89,"h":79,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":205,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":260,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":315,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":370,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":425,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":480,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":534,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":588,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":151,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":206,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":261,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":316,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":371,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":426,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":480,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":534,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":165,"w":480,"h":26,"txtscale":100}
,
"text234944":{"x":0,"y":220,"w":480,"h":26,"txtscale":100}
,
"text23349":{"x":0,"y":275,"w":480,"h":26,"txtscale":100}
,
"text23352":{"x":0,"y":329,"w":480,"h":26,"txtscale":100}
,
"text23355":{"x":0,"y":386,"w":480,"h":26,"txtscale":100}
,
"text23358":{"x":0,"y":440,"w":480,"h":26,"txtscale":100}
,
"text232929":{"x":0,"y":494,"w":480,"h":26,"txtscale":100}
,
"text233029":{"x":0,"y":546,"w":480,"h":26,"txtscale":100}
,
"button278429":{"x":181,"y":214,"w":135,"h":57,"stylemods":[{"sel":"div.button278429Text","decl":" { position:absolute; left:5px; top:2px; width:121px; height:49px;}"},{"sel":"span.button278429Text","decl":" { display:table-cell; position:relative; width:121px; height:49px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278429.png","irol":"images/PhonePortrait_button278429_over.png","ion":"images/PhonePortrait_button278429_down.png","idis":"images/PhonePortrait_button278429_disabled.png"}
,
"button278440":{"x":313,"y":354,"w":62,"h":56,"stylemods":[{"sel":"div.button278440Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278440Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278440.png","irol":"images/PhonePortrait_button278440_over.png","ion":"images/PhonePortrait_button278440_down.png","idis":"images/PhonePortrait_button278440_disabled.png"}
,
"button278447":{"x":378,"y":355,"w":62,"h":56,"stylemods":[{"sel":"div.button278447Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278447Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278447.png","irol":"images/PhonePortrait_button278447_over.png","ion":"images/PhonePortrait_button278447_down.png","idis":"images/PhonePortrait_button278447_disabled.png"}
,
"button278454":{"x":311,"y":413,"w":62,"h":56,"stylemods":[{"sel":"div.button278454Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278454Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278454.png","irol":"images/PhonePortrait_button278454_over.png","ion":"images/PhonePortrait_button278454_down.png","idis":"images/PhonePortrait_button278454_disabled.png"}
,
"button278461":{"x":377,"y":413,"w":62,"h":56,"stylemods":[{"sel":"div.button278461Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278461Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278461.png","irol":"images/PhonePortrait_button278461_over.png","ion":"images/PhonePortrait_button278461_down.png","idis":"images/PhonePortrait_button278461_disabled.png"}
,
"button278468":{"x":312,"y":473,"w":62,"h":56,"stylemods":[{"sel":"div.button278468Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278468Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278468.png","irol":"images/PhonePortrait_button278468_over.png","ion":"images/PhonePortrait_button278468_down.png","idis":"images/PhonePortrait_button278468_disabled.png"}
,
"button278475":{"x":378,"y":474,"w":62,"h":56,"stylemods":[{"sel":"div.button278475Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278475Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278475.png","irol":"images/PhonePortrait_button278475_over.png","ion":"images/PhonePortrait_button278475_down.png","idis":"images/PhonePortrait_button278475_disabled.png"}
,
"button278482":{"x":312,"y":535,"w":62,"h":56,"stylemods":[{"sel":"div.button278482Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278482Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278482.png","irol":"images/PhonePortrait_button278482_over.png","ion":"images/PhonePortrait_button278482_down.png","idis":"images/PhonePortrait_button278482_disabled.png"}
,
"button278489":{"x":377,"y":535,"w":62,"h":56,"stylemods":[{"sel":"div.button278489Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278489Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278489.png","irol":"images/PhonePortrait_button278489_over.png","ion":"images/PhonePortrait_button278489_down.png","idis":"images/PhonePortrait_button278489_disabled.png"}
,
"button278879":{"x":312,"y":595,"w":62,"h":56,"stylemods":[{"sel":"div.button278879Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278879Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278879.png","irol":"images/PhonePortrait_button278879_over.png","ion":"images/PhonePortrait_button278879_down.png","idis":"images/PhonePortrait_button278879_disabled.png"}
,
"button278872":{"x":377,"y":595,"w":62,"h":56,"stylemods":[{"sel":"div.button278872Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278872Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278872.png","irol":"images/PhonePortrait_button278872_over.png","ion":"images/PhonePortrait_button278872_down.png","idis":"images/PhonePortrait_button278872_disabled.png"}
,
"shape141298":{"x":-43,"y":125,"w":27,"h":28,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape141298.png"}
,
"shape231677":{"x":-43,"y":185,"w":27,"h":28,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231677.png"}
,
"shape231747":{"x":-43,"y":245,"w":27,"h":28,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231747.png"}
,
"shape231826":{"x":-43,"y":305,"w":27,"h":28,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":481,"h":687,"i":"images/bg_voilet.png"}
,
"button21550":{"x":48,"y":696,"w":62,"h":58,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21550.png","irol":"images/PhonePortrait_button21550_over.png","ion":"images/PhonePortrait_button21550_down.png","idis":"images/PhonePortrait_button21550_disabled.png"}
,
"button21689":{"x":366,"y":695,"w":62,"h":58,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21689.png","irol":"images/PhonePortrait_button21689_over.png","ion":"images/PhonePortrait_button21689_down.png","idis":"images/PhonePortrait_button21689_disabled.png"}
,
"text38077":{"x":96,"y":14,"w":289,"h":33,"txtscale":100}
,
"shape365091":{"x":121,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365091.png"}
,
"shape365089":{"x":178,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365089.png"}
,
"shape365087":{"x":235,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365087.png"}
,
"shape365085":{"x":292,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365085.png"}
,
"shape366845":{"x":120,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366845.png"}
,
"shape366843":{"x":149,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366843.png"}
,
"shape366841":{"x":178,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366841.png"}
,
"image278373":{"x":12,"y":76,"w":460,"h":606,"i":"images/text_bg.png"}
,
"text278374":{"x":54,"y":88,"w":373,"h":59,"txtscale":100}
,
"text278375":{"x":38,"y":139,"w":404,"h":87,"txtscale":100}
,
"text278376":{"x":38,"y":289,"w":261,"h":26,"txtscale":100}
,
"text278377":{"x":38,"y":327,"w":169,"h":34,"txtscale":100}
,
"text278378":{"x":38,"y":367,"w":269,"h":31,"txtscale":100}
,
"text278379":{"x":38,"y":427,"w":250,"h":30,"txtscale":100}
,
"text278380":{"x":38,"y":487,"w":250,"h":30,"txtscale":100}
,
"text278381":{"x":38,"y":547,"w":250,"h":30,"txtscale":100}
,
"text278892":{"x":38,"y":607,"w":250,"h":30,"txtscale":100}
,
"image278383":{"x":185,"y":216,"w":131,"h":53,"i":"images/remind_me.png"}
,
"text278384":{"x":234,"y":221,"w":74,"h":52,"txtscale":100}
,
"image278386":{"x":317,"y":356,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278388":{"x":315,"y":355,"w":60,"h":55,"i":"images/selected.png"}
,
"image278390":{"x":382,"y":356,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278392":{"x":381,"y":355,"w":60,"h":55,"i":"images/selected.png"}
,
"image278394":{"x":317,"y":416,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278396":{"x":315,"y":413,"w":60,"h":55,"i":"images/selected.png"}
,
"image278398":{"x":382,"y":416,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278400":{"x":380,"y":413,"w":60,"h":55,"i":"images/selected.png"}
,
"image278402":{"x":317,"y":476,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278404":{"x":315,"y":474,"w":60,"h":55,"i":"images/selected.png"}
,
"image278406":{"x":382,"y":476,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278408":{"x":381,"y":474,"w":60,"h":55,"i":"images/selected.png"}
,
"image278410":{"x":317,"y":536,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278412":{"x":315,"y":535,"w":60,"h":55,"i":"images/selected.png"}
,
"image278414":{"x":382,"y":536,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278416":{"x":381,"y":535,"w":60,"h":55,"i":"images/selected.png"}
,
"image278891":{"x":317,"y":596,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278889":{"x":315,"y":595,"w":60,"h":55,"i":"images/selected.png"}
,
"image278887":{"x":382,"y":596,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278885":{"x":381,"y":595,"w":60,"h":55,"i":"images/selected.png"}
,
"text278417":{"x":324,"y":370,"w":44,"h":24,"txtscale":100}
,
"text278418":{"x":389,"y":370,"w":44,"h":24,"txtscale":100}
,
"text278419":{"x":389,"y":430,"w":44,"h":24,"txtscale":100}
,
"text278420":{"x":324,"y":490,"w":44,"h":24,"txtscale":100}
,
"text278421":{"x":389,"y":551,"w":44,"h":24,"txtscale":100}
,
"text278422":{"x":324,"y":551,"w":44,"h":24,"txtscale":100}
,
"text278423":{"x":389,"y":490,"w":44,"h":24,"txtscale":100}
,
"text278424":{"x":324,"y":430,"w":44,"h":24,"txtscale":100}
,
"text278882":{"x":324,"y":611,"w":44,"h":24,"txtscale":100}
,
"text278883":{"x":389,"y":611,"w":44,"h":24,"txtscale":100}
,
"shape278500":{"x":21,"y":285,"w":429,"h":310,"stylemods":[{"sel":"div.shape278500Text","decl":" { position:absolute; left:5px; top:2px; width:415px; height:302px;}"},{"sel":"span.shape278500Text","decl":" { display:table-cell; position:relative; width:415px; height:302px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape278500.png"}
,
"text278501":{"x":44,"y":300,"w":394,"h":46,"txtscale":100}
,
"text278502":{"x":44,"y":356,"w":394,"h":46,"txtscale":100}
,
"text278503":{"x":44,"y":412,"w":394,"h":46,"txtscale":100}
,
"text278504":{"x":44,"y":468,"w":394,"h":46,"txtscale":100}
,
"text278505":{"x":44,"y":524,"w":394,"h":46,"txtscale":100}
,
"text324690":{"x":24,"y":300,"w":26,"h":26,"txtscale":100}
,
"text324689":{"x":24,"y":359,"w":26,"h":26,"txtscale":100}
,
"text324688":{"x":24,"y":418,"w":26,"h":26,"txtscale":100}
,
"text324687":{"x":24,"y":476,"w":26,"h":26,"txtscale":100}
,
"text324686":{"x":24,"y":535,"w":26,"h":26,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/remind_me.png','images/yes_n_no.png','images/selected.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_button21550.png','images/PhonePortrait_button21550_over.png','images/PhonePortrait_button21550_down.png','images/PhonePortrait_button21550_disabled.png','images/PhonePortrait_button21689.png','images/PhonePortrait_button21689_over.png','images/PhonePortrait_button21689_down.png','images/PhonePortrait_button21689_disabled.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_button278429.png','images/PhonePortrait_button278429_over.png','images/PhonePortrait_button278429_down.png','images/PhonePortrait_button278429_disabled.png','images/PhonePortrait_button278440.png','images/PhonePortrait_button278440_over.png','images/PhonePortrait_button278440_down.png','images/PhonePortrait_button278440_disabled.png','images/PhonePortrait_button278447.png','images/PhonePortrait_button278447_over.png','images/PhonePortrait_button278447_down.png','images/PhonePortrait_button278447_disabled.png','images/PhonePortrait_button278454.png','images/PhonePortrait_button278454_over.png','images/PhonePortrait_button278454_down.png','images/PhonePortrait_button278454_disabled.png','images/PhonePortrait_button278461.png','images/PhonePortrait_button278461_over.png','images/PhonePortrait_button278461_down.png','images/PhonePortrait_button278461_disabled.png','images/PhonePortrait_button278468.png','images/PhonePortrait_button278468_over.png','images/PhonePortrait_button278468_down.png','images/PhonePortrait_button278468_disabled.png','images/PhonePortrait_button278475.png','images/PhonePortrait_button278475_over.png','images/PhonePortrait_button278475_down.png','images/PhonePortrait_button278475_disabled.png','images/PhonePortrait_button278482.png','images/PhonePortrait_button278482_over.png','images/PhonePortrait_button278482_down.png','images/PhonePortrait_button278482_disabled.png','images/PhonePortrait_button278489.png','images/PhonePortrait_button278489_over.png','images/PhonePortrait_button278489_down.png','images/PhonePortrait_button278489_disabled.png','images/PhonePortrait_button278879.png','images/PhonePortrait_button278879_over.png','images/PhonePortrait_button278879_down.png','images/PhonePortrait_button278879_disabled.png','images/PhonePortrait_button278872.png','images/PhonePortrait_button278872_over.png','images/PhonePortrait_button278872_down.png','images/PhonePortrait_button278872_disabled.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape278500.png']
}}
