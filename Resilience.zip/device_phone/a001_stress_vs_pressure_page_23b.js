PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"image38007":{"x":14,"y":11,"w":30,"h":27,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":139,"y":-56,"w":790,"h":90,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:782px; height:82px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:782px; height:82px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape23327.png"}
,
"image23506":{"x":141,"y":24,"w":785,"h":372,"i":"images/menu_bg.png"}
,
"image23329":{"x":156,"y":-47,"w":20,"h":29,"i":"images/menu_hide.png"}
,
"image23332":{"x":497,"y":-46,"w":72,"h":63,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":141,"y":70,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":141,"y":113,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":141,"y":156,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":141,"y":199,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":141,"y":242,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":141,"y":285,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":141,"y":328,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":141,"y":371,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":141,"y":29,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image234952":{"x":141,"y":72,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23414":{"x":141,"y":115,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23412":{"x":141,"y":158,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23410":{"x":141,"y":201,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23408":{"x":141,"y":244,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image232937":{"x":141,"y":287,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image233037":{"x":141,"y":330,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"text23343":{"x":141,"y":37,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":141,"y":80,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":141,"y":123,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":141,"y":166,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":141,"y":209,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":141,"y":252,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":141,"y":295,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":141,"y":338,"w":785,"h":31,"txtscale":100}
,
"button278108":{"x":563,"y":113,"w":135,"h":55,"stylemods":[{"sel":"div.button278108Text","decl":" { position:absolute; left:5px; top:2px; width:121px; height:47px;}"},{"sel":"span.button278108Text","decl":" { display:table-cell; position:relative; width:121px; height:47px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278108.png","irol":"images/PhoneLandscape_button278108_over.png","ion":"images/PhoneLandscape_button278108_down.png","idis":"images/PhoneLandscape_button278108_disabled.png"}
,
"button278119":{"x":355,"y":204,"w":49,"h":44,"stylemods":[{"sel":"div.button278119Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278119Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278119.png","irol":"images/PhoneLandscape_button278119_over.png","ion":"images/PhoneLandscape_button278119_down.png","idis":"images/PhoneLandscape_button278119_disabled.png"}
,
"button278126":{"x":426,"y":203,"w":49,"h":44,"stylemods":[{"sel":"div.button278126Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278126Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278126.png","irol":"images/PhoneLandscape_button278126_over.png","ion":"images/PhoneLandscape_button278126_down.png","idis":"images/PhoneLandscape_button278126_disabled.png"}
,
"button278133":{"x":356,"y":248,"w":49,"h":44,"stylemods":[{"sel":"div.button278133Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278133Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278133.png","irol":"images/PhoneLandscape_button278133_over.png","ion":"images/PhoneLandscape_button278133_down.png","idis":"images/PhoneLandscape_button278133_disabled.png"}
,
"button278140":{"x":426,"y":248,"w":49,"h":44,"stylemods":[{"sel":"div.button278140Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278140Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278140.png","irol":"images/PhoneLandscape_button278140_over.png","ion":"images/PhoneLandscape_button278140_down.png","idis":"images/PhoneLandscape_button278140_disabled.png"}
,
"button278147":{"x":357,"y":292,"w":49,"h":44,"stylemods":[{"sel":"div.button278147Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278147Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278147.png","irol":"images/PhoneLandscape_button278147_over.png","ion":"images/PhoneLandscape_button278147_down.png","idis":"images/PhoneLandscape_button278147_disabled.png"}
,
"button278154":{"x":427,"y":294,"w":49,"h":44,"stylemods":[{"sel":"div.button278154Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278154Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278154.png","irol":"images/PhoneLandscape_button278154_over.png","ion":"images/PhoneLandscape_button278154_down.png","idis":"images/PhoneLandscape_button278154_disabled.png"}
,
"button278161":{"x":357,"y":338,"w":49,"h":44,"stylemods":[{"sel":"div.button278161Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278161Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278161.png","irol":"images/PhoneLandscape_button278161_over.png","ion":"images/PhoneLandscape_button278161_down.png","idis":"images/PhoneLandscape_button278161_disabled.png"}
,
"button278168":{"x":427,"y":338,"w":49,"h":44,"stylemods":[{"sel":"div.button278168Text","decl":" { position:absolute; left:7px; top:2px; width:31px; height:36px;}"},{"sel":"span.button278168Text","decl":" { display:table-cell; position:relative; width:31px; height:36px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button278168.png","irol":"images/PhoneLandscape_button278168_over.png","ion":"images/PhoneLandscape_button278168_down.png","idis":"images/PhoneLandscape_button278168_disabled.png"}
,
"shape141298":{"x":-70,"y":97,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape141298.png"}
,
"shape231677":{"x":-70,"y":143,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231677.png"}
,
"shape231747":{"x":-70,"y":190,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231747.png"}
,
"shape231826":{"x":-70,"y":237,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":787,"h":388,"i":"images/bg_voilet.png"}
,
"button21550":{"x":111,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21550.png","irol":"images/PhoneLandscape_button21550_over.png","ion":"images/PhoneLandscape_button21550_down.png","idis":"images/PhoneLandscape_button21550_disabled.png"}
,
"button21689":{"x":608,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21689.png","irol":"images/PhoneLandscape_button21689_over.png","ion":"images/PhoneLandscape_button21689_down.png","idis":"images/PhoneLandscape_button21689_disabled.png"}
,
"text38077":{"x":156,"y":13,"w":472,"h":34,"txtscale":100}
,
"shape365091":{"x":203,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365091.png"}
,
"shape365089":{"x":294,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365089.png"}
,
"shape365087":{"x":384,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365087.png"}
,
"shape365085":{"x":474,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365085.png"}
,
"shape366845":{"x":203,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366845.png"}
,
"shape366843":{"x":249,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366843.png"}
,
"shape366841":{"x":294,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366841.png"}
,
"image278052":{"x":53,"y":50,"w":679,"h":342,"i":"images/text_bg.png"}
,
"text278053":{"x":156,"y":68,"w":472,"h":42,"txtscale":100}
,
"text278054":{"x":80,"y":108,"w":467,"h":62,"txtscale":100}
,
"text278055":{"x":81,"y":163,"w":340,"h":29,"txtscale":100}
,
"text278056":{"x":81,"y":189,"w":197,"h":27,"txtscale":100}
,
"text278057":{"x":81,"y":219,"w":271,"h":29,"txtscale":100}
,
"text278058":{"x":81,"y":260,"w":222,"h":31,"txtscale":100}
,
"text278059":{"x":81,"y":303,"w":207,"h":27,"txtscale":100}
,
"text278060":{"x":81,"y":345,"w":209,"h":27,"txtscale":100}
,
"image278062":{"x":567,"y":113,"w":132,"h":54,"i":"images/remind_me.png"}
,
"text278063":{"x":607,"y":120,"w":88,"h":52,"txtscale":100}
,
"image278065":{"x":361,"y":207,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278067":{"x":359,"y":203,"w":47,"h":44,"i":"images/selected.png"}
,
"image278069":{"x":431,"y":207,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278071":{"x":429,"y":203,"w":47,"h":44,"i":"images/selected.png"}
,
"image278073":{"x":361,"y":250,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278075":{"x":359,"y":248,"w":47,"h":44,"i":"images/selected.png"}
,
"image278077":{"x":431,"y":250,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278079":{"x":429,"y":248,"w":47,"h":44,"i":"images/selected.png"}
,
"image278081":{"x":361,"y":294,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278083":{"x":360,"y":293,"w":47,"h":44,"i":"images/selected.png"}
,
"image278085":{"x":431,"y":294,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278087":{"x":430,"y":293,"w":47,"h":44,"i":"images/selected.png"}
,
"image278089":{"x":361,"y":339,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278091":{"x":360,"y":338,"w":47,"h":44,"i":"images/selected.png"}
,
"image278093":{"x":431,"y":339,"w":45,"h":40,"i":"images/yes_n_no.png"}
,
"image278095":{"x":430,"y":338,"w":47,"h":44,"i":"images/selected.png"}
,
"text278096":{"x":366,"y":217,"w":38,"h":24,"txtscale":100}
,
"text278097":{"x":435,"y":217,"w":38,"h":24,"txtscale":100}
,
"text278098":{"x":435,"y":260,"w":38,"h":24,"txtscale":100}
,
"text278099":{"x":366,"y":304,"w":38,"h":24,"txtscale":100}
,
"text278100":{"x":435,"y":348,"w":38,"h":24,"txtscale":100}
,
"text278101":{"x":366,"y":348,"w":38,"h":24,"txtscale":100}
,
"text278102":{"x":435,"y":304,"w":38,"h":24,"txtscale":100}
,
"text278103":{"x":366,"y":260,"w":38,"h":24,"txtscale":100}
,
"shape278179":{"x":100,"y":114,"w":460,"h":216,"stylemods":[{"sel":"div.shape278179Text","decl":" { position:absolute; left:4px; top:2px; width:448px; height:208px;}"},{"sel":"span.shape278179Text","decl":" { display:table-cell; position:relative; width:448px; height:208px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape278179.png"}
,
"text278180":{"x":142,"y":123,"w":405,"h":36,"txtscale":100}
,
"text278181":{"x":142,"y":163,"w":405,"h":36,"txtscale":100}
,
"text278182":{"x":142,"y":202,"w":405,"h":36,"txtscale":100}
,
"text278183":{"x":142,"y":242,"w":405,"h":36,"txtscale":100}
,
"text278184":{"x":142,"y":282,"w":405,"h":36,"txtscale":100}
,
"text324279":{"x":110,"y":124,"w":26,"h":26,"txtscale":100}
,
"text324278":{"x":110,"y":164,"w":26,"h":26,"txtscale":100}
,
"text324277":{"x":110,"y":203,"w":26,"h":26,"txtscale":100}
,
"text324276":{"x":110,"y":243,"w":26,"h":26,"txtscale":100}
,
"text324275":{"x":110,"y":283,"w":26,"h":26,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/remind_me.png','images/yes_n_no.png','images/selected.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_button21550.png','images/PhoneLandscape_button21550_over.png','images/PhoneLandscape_button21550_down.png','images/PhoneLandscape_button21550_disabled.png','images/PhoneLandscape_button21689.png','images/PhoneLandscape_button21689_over.png','images/PhoneLandscape_button21689_down.png','images/PhoneLandscape_button21689_disabled.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_button278108.png','images/PhoneLandscape_button278108_over.png','images/PhoneLandscape_button278108_down.png','images/PhoneLandscape_button278108_disabled.png','images/PhoneLandscape_button278119.png','images/PhoneLandscape_button278119_over.png','images/PhoneLandscape_button278119_down.png','images/PhoneLandscape_button278119_disabled.png','images/PhoneLandscape_button278126.png','images/PhoneLandscape_button278126_over.png','images/PhoneLandscape_button278126_down.png','images/PhoneLandscape_button278126_disabled.png','images/PhoneLandscape_button278133.png','images/PhoneLandscape_button278133_over.png','images/PhoneLandscape_button278133_down.png','images/PhoneLandscape_button278133_disabled.png','images/PhoneLandscape_button278140.png','images/PhoneLandscape_button278140_over.png','images/PhoneLandscape_button278140_down.png','images/PhoneLandscape_button278140_disabled.png','images/PhoneLandscape_button278147.png','images/PhoneLandscape_button278147_over.png','images/PhoneLandscape_button278147_down.png','images/PhoneLandscape_button278147_disabled.png','images/PhoneLandscape_button278154.png','images/PhoneLandscape_button278154_over.png','images/PhoneLandscape_button278154_down.png','images/PhoneLandscape_button278154_disabled.png','images/PhoneLandscape_button278161.png','images/PhoneLandscape_button278161_over.png','images/PhoneLandscape_button278161_down.png','images/PhoneLandscape_button278161_disabled.png','images/PhoneLandscape_button278168.png','images/PhoneLandscape_button278168_over.png','images/PhoneLandscape_button278168_down.png','images/PhoneLandscape_button278168_disabled.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366845.png','images/PhoneLandscape_shape366843.png','images/PhoneLandscape_shape366841.png','images/PhoneLandscape_shape278179.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"image38007":{"x":13,"y":14,"w":24,"h":23,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":483,"h":144,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:475px; height:136px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:475px; height:136px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape23327.png"}
,
"image23506":{"x":0,"y":141,"w":480,"h":622,"i":"images/menu_bg.png"}
,
"image23329":{"x":9,"y":10,"w":24,"h":34,"i":"images/menu_hide.png"}
,
"image23332":{"x":196,"y":31,"w":89,"h":79,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":205,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":260,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":315,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":370,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":425,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":480,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":534,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":588,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":151,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":206,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":261,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":316,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":371,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":426,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":480,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":534,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":165,"w":480,"h":26,"txtscale":100}
,
"text234944":{"x":0,"y":220,"w":480,"h":26,"txtscale":100}
,
"text23349":{"x":0,"y":275,"w":480,"h":26,"txtscale":100}
,
"text23352":{"x":0,"y":329,"w":480,"h":26,"txtscale":100}
,
"text23355":{"x":0,"y":386,"w":480,"h":26,"txtscale":100}
,
"text23358":{"x":0,"y":440,"w":480,"h":26,"txtscale":100}
,
"text232929":{"x":0,"y":494,"w":480,"h":26,"txtscale":100}
,
"text233029":{"x":0,"y":546,"w":480,"h":26,"txtscale":100}
,
"button278108":{"x":171,"y":214,"w":135,"h":57,"stylemods":[{"sel":"div.button278108Text","decl":" { position:absolute; left:5px; top:2px; width:121px; height:49px;}"},{"sel":"span.button278108Text","decl":" { display:table-cell; position:relative; width:121px; height:49px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278108.png","irol":"images/PhonePortrait_button278108_over.png","ion":"images/PhonePortrait_button278108_down.png","idis":"images/PhonePortrait_button278108_disabled.png"}
,
"button278119":{"x":313,"y":354,"w":62,"h":56,"stylemods":[{"sel":"div.button278119Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278119Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278119.png","irol":"images/PhonePortrait_button278119_over.png","ion":"images/PhonePortrait_button278119_down.png","idis":"images/PhonePortrait_button278119_disabled.png"}
,
"button278126":{"x":378,"y":355,"w":62,"h":56,"stylemods":[{"sel":"div.button278126Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278126Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278126.png","irol":"images/PhonePortrait_button278126_over.png","ion":"images/PhonePortrait_button278126_down.png","idis":"images/PhonePortrait_button278126_disabled.png"}
,
"button278133":{"x":311,"y":413,"w":62,"h":56,"stylemods":[{"sel":"div.button278133Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278133Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278133.png","irol":"images/PhonePortrait_button278133_over.png","ion":"images/PhonePortrait_button278133_down.png","idis":"images/PhonePortrait_button278133_disabled.png"}
,
"button278140":{"x":377,"y":413,"w":62,"h":56,"stylemods":[{"sel":"div.button278140Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278140Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278140.png","irol":"images/PhonePortrait_button278140_over.png","ion":"images/PhonePortrait_button278140_down.png","idis":"images/PhonePortrait_button278140_disabled.png"}
,
"button278147":{"x":312,"y":473,"w":62,"h":56,"stylemods":[{"sel":"div.button278147Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278147Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278147.png","irol":"images/PhonePortrait_button278147_over.png","ion":"images/PhonePortrait_button278147_down.png","idis":"images/PhonePortrait_button278147_disabled.png"}
,
"button278154":{"x":378,"y":474,"w":62,"h":56,"stylemods":[{"sel":"div.button278154Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278154Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278154.png","irol":"images/PhonePortrait_button278154_over.png","ion":"images/PhonePortrait_button278154_down.png","idis":"images/PhonePortrait_button278154_disabled.png"}
,
"button278161":{"x":312,"y":535,"w":62,"h":56,"stylemods":[{"sel":"div.button278161Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278161Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278161.png","irol":"images/PhonePortrait_button278161_over.png","ion":"images/PhonePortrait_button278161_down.png","idis":"images/PhonePortrait_button278161_disabled.png"}
,
"button278168":{"x":377,"y":535,"w":62,"h":56,"stylemods":[{"sel":"div.button278168Text","decl":" { position:absolute; left:8px; top:2px; width:42px; height:48px;}"},{"sel":"span.button278168Text","decl":" { display:table-cell; position:relative; width:42px; height:48px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button278168.png","irol":"images/PhonePortrait_button278168_over.png","ion":"images/PhonePortrait_button278168_down.png","idis":"images/PhonePortrait_button278168_disabled.png"}
,
"shape141298":{"x":-43,"y":125,"w":27,"h":28,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape141298.png"}
,
"shape231677":{"x":-43,"y":185,"w":27,"h":28,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231677.png"}
,
"shape231747":{"x":-43,"y":245,"w":27,"h":28,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231747.png"}
,
"shape231826":{"x":-43,"y":305,"w":27,"h":28,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":481,"h":687,"i":"images/bg_voilet.png"}
,
"button21550":{"x":48,"y":696,"w":62,"h":58,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21550.png","irol":"images/PhonePortrait_button21550_over.png","ion":"images/PhonePortrait_button21550_down.png","idis":"images/PhonePortrait_button21550_disabled.png"}
,
"button21689":{"x":366,"y":695,"w":62,"h":58,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21689.png","irol":"images/PhonePortrait_button21689_over.png","ion":"images/PhonePortrait_button21689_down.png","idis":"images/PhonePortrait_button21689_disabled.png"}
,
"text38077":{"x":96,"y":14,"w":289,"h":33,"txtscale":100}
,
"shape365091":{"x":121,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365091.png"}
,
"shape365089":{"x":178,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365089.png"}
,
"shape365087":{"x":235,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365087.png"}
,
"shape365085":{"x":292,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365085.png"}
,
"shape366845":{"x":120,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366845.png"}
,
"shape366843":{"x":149,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366843.png"}
,
"shape366841":{"x":178,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366841.png"}
,
"image278052":{"x":12,"y":76,"w":460,"h":559,"i":"images/text_bg.png"}
,
"text278053":{"x":54,"y":88,"w":373,"h":59,"txtscale":100}
,
"text278054":{"x":38,"y":139,"w":404,"h":87,"txtscale":100}
,
"text278055":{"x":38,"y":289,"w":261,"h":26,"txtscale":100}
,
"text278056":{"x":38,"y":327,"w":169,"h":34,"txtscale":100}
,
"text278057":{"x":38,"y":367,"w":269,"h":31,"txtscale":100}
,
"text278058":{"x":38,"y":427,"w":250,"h":30,"txtscale":100}
,
"text278059":{"x":38,"y":487,"w":250,"h":30,"txtscale":100}
,
"text278060":{"x":38,"y":547,"w":250,"h":30,"txtscale":100}
,
"image278062":{"x":175,"y":216,"w":131,"h":53,"i":"images/remind_me.png"}
,
"text278063":{"x":224,"y":221,"w":74,"h":52,"txtscale":100}
,
"image278065":{"x":317,"y":356,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278067":{"x":315,"y":355,"w":60,"h":55,"i":"images/selected.png"}
,
"image278069":{"x":382,"y":356,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278071":{"x":381,"y":355,"w":60,"h":55,"i":"images/selected.png"}
,
"image278073":{"x":317,"y":416,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278075":{"x":315,"y":413,"w":60,"h":55,"i":"images/selected.png"}
,
"image278077":{"x":382,"y":416,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278079":{"x":380,"y":413,"w":60,"h":55,"i":"images/selected.png"}
,
"image278081":{"x":317,"y":476,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278083":{"x":315,"y":474,"w":60,"h":55,"i":"images/selected.png"}
,
"image278085":{"x":382,"y":476,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278087":{"x":381,"y":474,"w":60,"h":55,"i":"images/selected.png"}
,
"image278089":{"x":317,"y":536,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278091":{"x":315,"y":535,"w":60,"h":55,"i":"images/selected.png"}
,
"image278093":{"x":382,"y":536,"w":58,"h":52,"i":"images/yes_n_no.png"}
,
"image278095":{"x":381,"y":535,"w":60,"h":55,"i":"images/selected.png"}
,
"text278096":{"x":324,"y":370,"w":44,"h":24,"txtscale":100}
,
"text278097":{"x":389,"y":370,"w":44,"h":24,"txtscale":100}
,
"text278098":{"x":389,"y":430,"w":44,"h":24,"txtscale":100}
,
"text278099":{"x":324,"y":490,"w":44,"h":24,"txtscale":100}
,
"text278100":{"x":389,"y":551,"w":44,"h":24,"txtscale":100}
,
"text278101":{"x":324,"y":551,"w":44,"h":24,"txtscale":100}
,
"text278102":{"x":389,"y":490,"w":44,"h":24,"txtscale":100}
,
"text278103":{"x":324,"y":430,"w":44,"h":24,"txtscale":100}
,
"shape278179":{"x":21,"y":285,"w":428,"h":310,"stylemods":[{"sel":"div.shape278179Text","decl":" { position:absolute; left:5px; top:2px; width:414px; height:302px;}"},{"sel":"span.shape278179Text","decl":" { display:table-cell; position:relative; width:414px; height:302px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape278179.png"}
,
"text278180":{"x":57,"y":300,"w":394,"h":46,"txtscale":100}
,
"text278181":{"x":57,"y":356,"w":394,"h":46,"txtscale":100}
,
"text278182":{"x":57,"y":412,"w":394,"h":46,"txtscale":100}
,
"text278183":{"x":57,"y":468,"w":394,"h":46,"txtscale":100}
,
"text278184":{"x":57,"y":524,"w":394,"h":46,"txtscale":100}
,
"text324279":{"x":24,"y":300,"w":26,"h":26,"txtscale":100}
,
"text324278":{"x":24,"y":359,"w":26,"h":26,"txtscale":100}
,
"text324277":{"x":24,"y":412,"w":26,"h":26,"txtscale":100}
,
"text324276":{"x":24,"y":470,"w":26,"h":26,"txtscale":100}
,
"text324275":{"x":24,"y":529,"w":26,"h":26,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/remind_me.png','images/yes_n_no.png','images/selected.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_button21550.png','images/PhonePortrait_button21550_over.png','images/PhonePortrait_button21550_down.png','images/PhonePortrait_button21550_disabled.png','images/PhonePortrait_button21689.png','images/PhonePortrait_button21689_over.png','images/PhonePortrait_button21689_down.png','images/PhonePortrait_button21689_disabled.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_button278108.png','images/PhonePortrait_button278108_over.png','images/PhonePortrait_button278108_down.png','images/PhonePortrait_button278108_disabled.png','images/PhonePortrait_button278119.png','images/PhonePortrait_button278119_over.png','images/PhonePortrait_button278119_down.png','images/PhonePortrait_button278119_disabled.png','images/PhonePortrait_button278126.png','images/PhonePortrait_button278126_over.png','images/PhonePortrait_button278126_down.png','images/PhonePortrait_button278126_disabled.png','images/PhonePortrait_button278133.png','images/PhonePortrait_button278133_over.png','images/PhonePortrait_button278133_down.png','images/PhonePortrait_button278133_disabled.png','images/PhonePortrait_button278140.png','images/PhonePortrait_button278140_over.png','images/PhonePortrait_button278140_down.png','images/PhonePortrait_button278140_disabled.png','images/PhonePortrait_button278147.png','images/PhonePortrait_button278147_over.png','images/PhonePortrait_button278147_down.png','images/PhonePortrait_button278147_disabled.png','images/PhonePortrait_button278154.png','images/PhonePortrait_button278154_over.png','images/PhonePortrait_button278154_down.png','images/PhonePortrait_button278154_disabled.png','images/PhonePortrait_button278161.png','images/PhonePortrait_button278161_over.png','images/PhonePortrait_button278161_down.png','images/PhonePortrait_button278161_disabled.png','images/PhonePortrait_button278168.png','images/PhonePortrait_button278168_over.png','images/PhonePortrait_button278168_down.png','images/PhonePortrait_button278168_disabled.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366845.png','images/PhonePortrait_shape366843.png','images/PhonePortrait_shape366841.png','images/PhonePortrait_shape278179.png']
}}
