PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#ffffff"}
,
"image38007":{"x":14,"y":11,"w":30,"h":27,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":139,"y":-56,"w":790,"h":90,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:782px; height:82px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:782px; height:82px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape23327.png"}
,
"image23506":{"x":141,"y":24,"w":785,"h":372,"i":"images/menu_bg.png"}
,
"image23329":{"x":156,"y":-47,"w":20,"h":29,"i":"images/menu_hide.png"}
,
"image23332":{"x":497,"y":-46,"w":72,"h":63,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":141,"y":70,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":141,"y":113,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":141,"y":156,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":141,"y":199,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":141,"y":242,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":141,"y":285,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":141,"y":328,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":141,"y":371,"w":785,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":141,"y":29,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image234952":{"x":141,"y":72,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23414":{"x":141,"y":115,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23412":{"x":141,"y":158,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23410":{"x":141,"y":201,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image23408":{"x":141,"y":244,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image232937":{"x":141,"y":287,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"image233037":{"x":141,"y":330,"w":785,"h":40,"i":"images/menu_selected.png"}
,
"text23343":{"x":141,"y":37,"w":785,"h":31,"txtscale":100}
,
"text234944":{"x":141,"y":80,"w":785,"h":31,"txtscale":100}
,
"text23349":{"x":141,"y":123,"w":785,"h":31,"txtscale":100}
,
"text23352":{"x":141,"y":166,"w":785,"h":31,"txtscale":100}
,
"text23355":{"x":141,"y":209,"w":785,"h":31,"txtscale":100}
,
"text23358":{"x":141,"y":252,"w":785,"h":31,"txtscale":100}
,
"text232929":{"x":141,"y":295,"w":785,"h":31,"txtscale":100}
,
"text233029":{"x":141,"y":338,"w":785,"h":31,"txtscale":100}
,
"button260454":{"x":460,"y":206,"w":44,"h":43,"stylemods":[{"sel":"div.button260454Text","decl":" { position:absolute; left:3px; top:2px; width:34px; height:35px;}"},{"sel":"span.button260454Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button260454.png","irol":"images/PhoneLandscape_button260454_over.png","ion":"images/PhoneLandscape_button260454_down.png","idis":"images/PhoneLandscape_button260454_disabled.png"}
,
"button260464":{"x":103,"y":206,"w":44,"h":43,"stylemods":[{"sel":"div.button260464Text","decl":" { position:absolute; left:3px; top:2px; width:34px; height:35px;}"},{"sel":"span.button260464Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button260464.png","irol":"images/PhoneLandscape_button260464_over.png","ion":"images/PhoneLandscape_button260464_down.png","idis":"images/PhoneLandscape_button260464_disabled.png"}
,
"shape141298":{"x":-70,"y":97,"w":42,"h":43,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape141298.png"}
,
"shape231677":{"x":-70,"y":143,"w":42,"h":43,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231677.png"}
,
"shape231747":{"x":-70,"y":190,"w":42,"h":43,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231747.png"}
,
"shape231826":{"x":-70,"y":237,"w":42,"h":43,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:34px; height:35px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":787,"h":388,"i":"images/bg_voilet.png"}
,
"button21550":{"x":111,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21550.png","irol":"images/PhoneLandscape_button21550_over.png","ion":"images/PhoneLandscape_button21550_down.png","idis":"images/PhoneLandscape_button21550_disabled.png"}
,
"button21689":{"x":608,"y":390,"w":62,"h":57,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:49px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:49px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_button21689.png","irol":"images/PhoneLandscape_button21689_over.png","ion":"images/PhoneLandscape_button21689_down.png","idis":"images/PhoneLandscape_button21689_disabled.png"}
,
"text38077":{"x":156,"y":13,"w":472,"h":34,"txtscale":100}
,
"shape365091":{"x":203,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365091.png"}
,
"shape365089":{"x":294,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365089.png"}
,
"shape365087":{"x":384,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365087.png"}
,
"shape365085":{"x":474,"y":413,"w":93,"h":13,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:85px; height:5px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:85px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape365085.png"}
,
"shape366800":{"x":203,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366800Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366800Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366800.png"}
,
"shape366798":{"x":249,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366798Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366798Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366798.png"}
,
"shape366796":{"x":294,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366796Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366796Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366796.png"}
,
"shape366794":{"x":339,"y":413,"w":48,"h":13,"stylemods":[{"sel":"div.shape366794Text","decl":" { position:absolute; left:2px; top:2px; width:40px; height:5px;}"},{"sel":"span.shape366794Text","decl":" { display:table-cell; position:relative; width:40px; height:5px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape366794.png"}
,
"image260414":{"x":76,"y":50,"w":633,"h":343,"i":"images/text_bg.png"}
,
"text260415":{"x":156,"y":68,"w":472,"h":42,"txtscale":100}
,
"text260416":{"x":104,"y":118,"w":643,"h":32,"txtscale":100}
,
"text260417":{"x":104,"y":156,"w":405,"h":29,"txtscale":100}
,
"text260418":{"x":107,"y":248,"w":90,"h":42,"txtscale":100}
,
"text260419":{"x":217,"y":248,"w":89,"h":36,"txtscale":100}
,
"text260420":{"x":326,"y":248,"w":69,"h":38,"txtscale":100}
,
"text260421":{"x":415,"y":248,"w":67,"h":36,"txtscale":100}
,
"text260422":{"x":102,"y":186,"w":410,"h":29,"txtscale":100}
,
"text260423":{"x":102,"y":287,"w":409,"h":26,"txtscale":100}
,
"text260424":{"x":102,"y":326,"w":303,"h":52,"txtscale":100}
,
"image260426":{"x":274,"y":283,"w":406,"h":38,"i":"images/textentry_bg.png"}
,
"entry260428":{"x":277,"y":283,"w":398,"h":32,"fsize":16}
,
"image260430":{"x":404,"y":336,"w":276,"h":38,"i":"images/textentry_bg.png"}
,
"entry260432":{"x":407,"y":336,"w":267,"h":32,"fsize":16}
,
"image260434":{"x":113,"y":215,"w":388,"h":27,"i":"images/bg2.png"}
,
"shape260436":{"x":146,"y":220,"w":316,"h":17,"stylemods":[{"sel":"div.shape260436Text","decl":" { position:absolute; left:2px; top:2px; width:308px; height:9px;}"},{"sel":"span.shape260436Text","decl":" { display:table-cell; position:relative; width:308px; height:9px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260436.png"}
,
"shape260439":{"x":145,"y":214,"w":321,"h":28,"stylemods":[{"sel":"div.shape260439Text","decl":" { position:absolute; left:2px; top:2px; width:313px; height:20px;}"},{"sel":"span.shape260439Text","decl":" { display:table-cell; position:relative; width:313px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260439.png"}
,
"shape260441":{"x":218,"y":214,"w":248,"h":28,"stylemods":[{"sel":"div.shape260441Text","decl":" { position:absolute; left:2px; top:2px; width:240px; height:20px;}"},{"sel":"span.shape260441Text","decl":" { display:table-cell; position:relative; width:240px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260441.png"}
,
"shape260443":{"x":318,"y":214,"w":148,"h":28,"stylemods":[{"sel":"div.shape260443Text","decl":" { position:absolute; left:2px; top:2px; width:140px; height:20px;}"},{"sel":"span.shape260443Text","decl":" { display:table-cell; position:relative; width:140px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260443.png"}
,
"shape260445":{"x":405,"y":214,"w":61,"h":28,"stylemods":[{"sel":"div.shape260445Text","decl":" { position:absolute; left:2px; top:2px; width:53px; height:20px;}"},{"sel":"span.shape260445Text","decl":" { display:table-cell; position:relative; width:53px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260445.png"}
,
"shape260447":{"x":117,"y":218,"w":17,"h":22,"stylemods":[{"sel":"div.shape260447Text","decl":" { position:absolute; left:2px; top:2px; width:9px; height:14px;}"},{"sel":"span.shape260447Text","decl":" { display:table-cell; position:relative; width:9px; height:14px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260447.png"}
,
"shape260449":{"x":478,"y":219,"w":17,"h":21,"stylemods":[{"sel":"div.shape260449Text","decl":" { position:absolute; left:3px; top:3px; width:9px; height:13px;}"},{"sel":"span.shape260449Text","decl":" { display:table-cell; position:relative; width:9px; height:13px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhoneLandscape_shape260449.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/textentry_bg.png','images/bg2.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_button21550.png','images/PhoneLandscape_button21550_over.png','images/PhoneLandscape_button21550_down.png','images/PhoneLandscape_button21550_disabled.png','images/PhoneLandscape_button21689.png','images/PhoneLandscape_button21689_over.png','images/PhoneLandscape_button21689_down.png','images/PhoneLandscape_button21689_disabled.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape23327.png','images/PhoneLandscape_button260454.png','images/PhoneLandscape_button260454_over.png','images/PhoneLandscape_button260454_down.png','images/PhoneLandscape_button260454_disabled.png','images/PhoneLandscape_button260464.png','images/PhoneLandscape_button260464_over.png','images/PhoneLandscape_button260464_down.png','images/PhoneLandscape_button260464_disabled.png','images/PhoneLandscape_shape141298.png','images/PhoneLandscape_shape231677.png','images/PhoneLandscape_shape231747.png','images/PhoneLandscape_shape231826.png','images/PhoneLandscape_shape365091.png','images/PhoneLandscape_shape365089.png','images/PhoneLandscape_shape365087.png','images/PhoneLandscape_shape365085.png','images/PhoneLandscape_shape366800.png','images/PhoneLandscape_shape366798.png','images/PhoneLandscape_shape366796.png','images/PhoneLandscape_shape366794.png','images/PhoneLandscape_shape260436.png','images/PhoneLandscape_shape260439.png','images/PhoneLandscape_shape260441.png','images/PhoneLandscape_shape260443.png','images/PhoneLandscape_shape260445.png','images/PhoneLandscape_shape260447.png','images/PhoneLandscape_shape260449.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff"}
,
"image38007":{"x":13,"y":14,"w":24,"h":23,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-2,"y":-1,"w":483,"h":144,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:475px; height:136px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:475px; height:136px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape23327.png"}
,
"image23506":{"x":0,"y":141,"w":480,"h":622,"i":"images/menu_bg.png"}
,
"image23329":{"x":9,"y":10,"w":24,"h":34,"i":"images/menu_hide.png"}
,
"image23332":{"x":196,"y":31,"w":89,"h":79,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":205,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":260,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":315,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":370,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":425,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":480,"w":480,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":534,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":588,"w":480,"h":1,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":151,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":206,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":261,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":316,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":371,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":426,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":480,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":534,"w":480,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":165,"w":480,"h":26,"txtscale":100}
,
"text234944":{"x":0,"y":220,"w":480,"h":26,"txtscale":100}
,
"text23349":{"x":0,"y":275,"w":480,"h":26,"txtscale":100}
,
"text23352":{"x":0,"y":329,"w":480,"h":26,"txtscale":100}
,
"text23355":{"x":0,"y":386,"w":480,"h":26,"txtscale":100}
,
"text23358":{"x":0,"y":440,"w":480,"h":26,"txtscale":100}
,
"text232929":{"x":0,"y":494,"w":480,"h":26,"txtscale":100}
,
"text233029":{"x":0,"y":546,"w":480,"h":26,"txtscale":100}
,
"button260454":{"x":395,"y":294,"w":44,"h":43,"stylemods":[{"sel":"div.button260454Text","decl":" { position:absolute; left:3px; top:2px; width:34px; height:35px;}"},{"sel":"span.button260454Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button260454.png","irol":"images/PhonePortrait_button260454_over.png","ion":"images/PhonePortrait_button260454_down.png","idis":"images/PhonePortrait_button260454_disabled.png"}
,
"button260464":{"x":34,"y":294,"w":44,"h":43,"stylemods":[{"sel":"div.button260464Text","decl":" { position:absolute; left:3px; top:2px; width:34px; height:35px;}"},{"sel":"span.button260464Text","decl":" { display:table-cell; position:relative; width:34px; height:35px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button260464.png","irol":"images/PhonePortrait_button260464_over.png","ion":"images/PhonePortrait_button260464_down.png","idis":"images/PhonePortrait_button260464_disabled.png"}
,
"shape141298":{"x":-43,"y":125,"w":27,"h":28,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape141298.png"}
,
"shape231677":{"x":-43,"y":185,"w":27,"h":28,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231677.png"}
,
"shape231747":{"x":-43,"y":245,"w":27,"h":28,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231747.png"}
,
"shape231826":{"x":-43,"y":305,"w":27,"h":28,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:19px; height:20px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:19px; height:20px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":481,"h":687,"i":"images/bg_voilet.png"}
,
"button21550":{"x":48,"y":696,"w":62,"h":58,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21550.png","irol":"images/PhonePortrait_button21550_over.png","ion":"images/PhonePortrait_button21550_down.png","idis":"images/PhonePortrait_button21550_disabled.png"}
,
"button21689":{"x":366,"y":695,"w":62,"h":58,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:54px; height:50px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:54px; height:50px; vertical-align:middle; text-align:center; line-height:15px; font-size:15px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_button21689.png","irol":"images/PhonePortrait_button21689_over.png","ion":"images/PhonePortrait_button21689_down.png","idis":"images/PhonePortrait_button21689_disabled.png"}
,
"text38077":{"x":96,"y":14,"w":289,"h":33,"txtscale":100}
,
"shape365091":{"x":121,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365091.png"}
,
"shape365089":{"x":178,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365089.png"}
,
"shape365087":{"x":235,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365087.png"}
,
"shape365085":{"x":292,"y":720,"w":58,"h":10,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:50px; height:2px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:50px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape365085.png"}
,
"shape366800":{"x":120,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366800Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366800Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366800.png"}
,
"shape366798":{"x":149,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366798Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366798Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366798.png"}
,
"shape366796":{"x":178,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366796Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366796Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366796.png"}
,
"shape366794":{"x":206,"y":720,"w":31,"h":10,"stylemods":[{"sel":"div.shape366794Text","decl":" { position:absolute; left:2px; top:2px; width:23px; height:2px;}"},{"sel":"span.shape366794Text","decl":" { display:table-cell; position:relative; width:23px; height:2px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape366794.png"}
,
"image260414":{"x":12,"y":71,"w":460,"h":563,"i":"images/text_bg.png"}
,
"text260415":{"x":54,"y":88,"w":373,"h":59,"txtscale":100}
,
"text260416":{"x":35,"y":150,"w":412,"h":52,"txtscale":100}
,
"text260417":{"x":35,"y":214,"w":412,"h":126,"txtscale":100}
,
"text260418":{"x":46,"y":334,"w":91,"h":45,"txtscale":100}
,
"text260419":{"x":153,"y":334,"w":87,"h":45,"txtscale":100}
,
"text260420":{"x":256,"y":334,"w":72,"h":44,"txtscale":100}
,
"text260421":{"x":346,"y":334,"w":77,"h":47,"txtscale":100}
,
"text260422":{"x":34,"y":254,"w":412,"h":34,"txtscale":100}
,
"text260423":{"x":34,"y":394,"w":412,"h":38,"txtscale":100}
,
"text260424":{"x":34,"y":494,"w":406,"h":54,"txtscale":100}
,
"image260426":{"x":31,"y":428,"w":412,"h":49,"i":"images/textentry_bg.png"}
,
"entry260428":{"x":34,"y":430,"w":404,"h":38,"fsize":16}
,
"image260430":{"x":31,"y":548,"w":412,"h":49,"i":"images/textentry_bg.png"}
,
"entry260432":{"x":34,"y":550,"w":404,"h":38,"fsize":16}
,
"image260434":{"x":46,"y":302,"w":388,"h":27,"i":"images/bg2.png"}
,
"shape260436":{"x":79,"y":307,"w":316,"h":17,"stylemods":[{"sel":"div.shape260436Text","decl":" { position:absolute; left:2px; top:2px; width:308px; height:9px;}"},{"sel":"span.shape260436Text","decl":" { display:table-cell; position:relative; width:308px; height:9px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260436.png"}
,
"shape260439":{"x":76,"y":301,"w":321,"h":28,"stylemods":[{"sel":"div.shape260439Text","decl":" { position:absolute; left:2px; top:2px; width:313px; height:20px;}"},{"sel":"span.shape260439Text","decl":" { display:table-cell; position:relative; width:313px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260439.png"}
,
"shape260441":{"x":149,"y":301,"w":248,"h":28,"stylemods":[{"sel":"div.shape260441Text","decl":" { position:absolute; left:2px; top:2px; width:240px; height:20px;}"},{"sel":"span.shape260441Text","decl":" { display:table-cell; position:relative; width:240px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260441.png"}
,
"shape260443":{"x":249,"y":301,"w":148,"h":28,"stylemods":[{"sel":"div.shape260443Text","decl":" { position:absolute; left:2px; top:2px; width:140px; height:20px;}"},{"sel":"span.shape260443Text","decl":" { display:table-cell; position:relative; width:140px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260443.png"}
,
"shape260445":{"x":336,"y":301,"w":61,"h":28,"stylemods":[{"sel":"div.shape260445Text","decl":" { position:absolute; left:2px; top:2px; width:53px; height:20px;}"},{"sel":"span.shape260445Text","decl":" { display:table-cell; position:relative; width:53px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260445.png"}
,
"shape260447":{"x":48,"y":304,"w":17,"h":22,"stylemods":[{"sel":"div.shape260447Text","decl":" { position:absolute; left:2px; top:2px; width:9px; height:14px;}"},{"sel":"span.shape260447Text","decl":" { display:table-cell; position:relative; width:9px; height:14px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260447.png"}
,
"shape260449":{"x":410,"y":305,"w":17,"h":21,"stylemods":[{"sel":"div.shape260449Text","decl":" { position:absolute; left:3px; top:3px; width:9px; height:13px;}"},{"sel":"span.shape260449Text","decl":" { display:table-cell; position:relative; width:9px; height:13px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/PhonePortrait_shape260449.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/textentry_bg.png','images/bg2.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_button21550.png','images/PhonePortrait_button21550_over.png','images/PhonePortrait_button21550_down.png','images/PhonePortrait_button21550_disabled.png','images/PhonePortrait_button21689.png','images/PhonePortrait_button21689_over.png','images/PhonePortrait_button21689_down.png','images/PhonePortrait_button21689_disabled.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape23327.png','images/PhonePortrait_button260454.png','images/PhonePortrait_button260454_over.png','images/PhonePortrait_button260454_down.png','images/PhonePortrait_button260454_disabled.png','images/PhonePortrait_button260464.png','images/PhonePortrait_button260464_over.png','images/PhonePortrait_button260464_down.png','images/PhonePortrait_button260464_disabled.png','images/PhonePortrait_shape141298.png','images/PhonePortrait_shape231677.png','images/PhonePortrait_shape231747.png','images/PhonePortrait_shape231826.png','images/PhonePortrait_shape365091.png','images/PhonePortrait_shape365089.png','images/PhonePortrait_shape365087.png','images/PhonePortrait_shape365085.png','images/PhonePortrait_shape366800.png','images/PhonePortrait_shape366798.png','images/PhonePortrait_shape366796.png','images/PhonePortrait_shape366794.png','images/PhonePortrait_shape260436.png','images/PhonePortrait_shape260439.png','images/PhonePortrait_shape260441.png','images/PhonePortrait_shape260443.png','images/PhonePortrait_shape260445.png','images/PhonePortrait_shape260447.png','images/PhonePortrait_shape260449.png']
}}
