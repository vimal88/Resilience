DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image38007":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"button195967":{"x":257,"y":277,"w":141,"h":60,"stylemods":[{"sel":"div.button195967Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button195967Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button195967.png","irol":"images/button195967_over.png","ion":"images/button195967_down.png","idis":"images/button195967_disabled.png"}
,
"button195979":{"x":257,"y":342,"w":141,"h":60,"stylemods":[{"sel":"div.button195979Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button195979Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button195979.png","irol":"images/button195979_over.png","ion":"images/button195979_down.png","idis":"images/button195979_disabled.png"}
,
"button195991":{"x":257,"y":406,"w":141,"h":60,"stylemods":[{"sel":"div.button195991Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button195991Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button195991.png","irol":"images/button195991_over.png","ion":"images/button195991_down.png","idis":"images/button195991_disabled.png"}
,
"button196003":{"x":257,"y":471,"w":141,"h":60,"stylemods":[{"sel":"div.button196003Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button196003Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button196003.png","irol":"images/button196003_over.png","ion":"images/button196003_down.png","idis":"images/button196003_disabled.png"}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":1012,"h":585,"i":"images/bg_voilet.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21689.png","irol":"images/button21689_over.png","ion":"images/button21689_down.png","idis":"images/button21689_disabled.png"}
,
"text38077":{"x":201,"y":17,"w":607,"h":36,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366588":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366588Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366588Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366588.png"}
,
"shape366586":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366586Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366586Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366586.png"}
,
"shape366584":{"x":378,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366584Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366584Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366584.png"}
,
"shape366582":{"x":436,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366582Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366582Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366582.png"}
,
"shape366580":{"x":494,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366580Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366580Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366580.png"}
,
"shape366578":{"x":552,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366578Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366578Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366578.png"}
,
"shape366576":{"x":610,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366576Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366576Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366576.png"}
,
"text195958":{"x":201,"y":88,"w":607,"h":53,"txtscale":100}
,
"text195959":{"x":263,"y":149,"w":498,"h":113,"txtscale":100}
,
"image195961":{"x":261,"y":279,"w":137,"h":55,"i":"images/button.png"}
,
"text195962":{"x":263,"y":294,"w":133,"h":28,"txtscale":100}
,
"image195973":{"x":261,"y":344,"w":137,"h":55,"i":"images/button.png"}
,
"text195974":{"x":263,"y":352,"w":133,"h":53,"txtscale":100}
,
"image195985":{"x":261,"y":408,"w":137,"h":55,"i":"images/button.png"}
,
"text195986":{"x":285,"y":415,"w":87,"h":52,"txtscale":100}
,
"image195997":{"x":261,"y":473,"w":137,"h":55,"i":"images/button.png"}
,
"text195998":{"x":263,"y":488,"w":133,"h":26,"txtscale":100}
,
"image196010":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape196012":{"x":402,"y":289,"w":36,"h":36,"stylemods":[{"sel":"div.shape196012Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape196012Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape196012.png"}
,
"text196013":{"x":455,"y":286,"w":306,"h":31,"txtscale":100}
,
"text196014":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image196023":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape196025":{"x":402,"y":354,"w":36,"h":36,"stylemods":[{"sel":"div.shape196025Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape196025Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape196025.png"}
,
"text196026":{"x":455,"y":286,"w":314,"h":53,"txtscale":100}
,
"text196027":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image196036":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape196038":{"x":402,"y":419,"w":36,"h":36,"stylemods":[{"sel":"div.shape196038Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape196038Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape196038.png"}
,
"text196039":{"x":455,"y":286,"w":303,"h":32,"txtscale":100}
,
"text196040":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image196049":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape196051":{"x":402,"y":483,"w":36,"h":36,"stylemods":[{"sel":"div.shape196051Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape196051Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape196051.png"}
,
"text196052":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text196053":{"x":455,"y":324,"w":300,"h":174,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/button.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/button21689.png','images/button21689_over.png','images/button21689_down.png','images/button21689_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366588.png','images/shape366586.png','images/shape366584.png','images/shape366582.png','images/shape366580.png','images/shape366578.png','images/shape366576.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366588.png','images/shape366586.png','images/shape366584.png','images/shape366582.png','images/shape366580.png','images/shape366578.png','images/shape366576.png','images/shape23327.png','images/button195967.png','images/button195967_over.png','images/button195967_down.png','images/button195967_disabled.png','images/button195979.png','images/button195979_over.png','images/button195979_down.png','images/button195979_disabled.png','images/button195991.png','images/button195991_over.png','images/button195991_down.png','images/button195991_disabled.png','images/button196003.png','images/button196003_over.png','images/button196003_down.png','images/button196003_disabled.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366588.png','images/shape366586.png','images/shape366584.png','images/shape366582.png','images/shape366580.png','images/shape366578.png','images/shape366576.png','images/shape196012.png','images/shape196025.png','images/shape196038.png','images/shape196051.png']
}}
