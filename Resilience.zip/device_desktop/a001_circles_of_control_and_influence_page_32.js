DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image5712":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_icon.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image24751":{"x":0,"y":0,"w":1010,"h":662,"i":"images/bg.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21689.png","irol":"images/button21689_over.png","ion":"images/button21689_down.png","idis":"images/button21689_disabled.png"}
,
"text24400":{"x":201,"y":17,"w":607,"h":35,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366733":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366733Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366733Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366733.png"}
,
"shape366731":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366731Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366731Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366731.png"}
,
"shape366729":{"x":378,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366729Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366729Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366729.png"}
,
"shape366727":{"x":436,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366727Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366727Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366727.png"}
,
"shape366725":{"x":494,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366725Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366725Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366725.png"}
,
"image170868":{"x":369,"y":202,"w":271,"h":272,"i":"images/concern.png"}
,
"image170967":{"x":422,"y":256,"w":164,"h":164,"i":"images/influence.png"}
,
"text88829":{"x":172,"y":88,"w":664,"h":45,"txtscale":100}
,
"text349107":{"x":172,"y":128,"w":664,"h":47,"txtscale":100}
,
"text349118":{"x":172,"y":168,"w":664,"h":46,"txtscale":100}
,
"text88830":{"x":345,"y":483,"w":317,"h":37,"txtscale":100}
,
"text171474":{"x":362,"y":218,"w":285,"h":29,"txtscale":100}
,
"text171562":{"x":388,"y":324,"w":233,"h":29,"txtscale":100}
,
"text88981":{"x":370,"y":529,"w":367,"h":27,"txtscale":100}
,
"image171893":{"x":280,"y":503,"w":80,"h":72,"i":"images/question_mark.png"}
,
"image172388":{"x":10,"y":223,"w":352,"h":227,"i":"images/text_bg.png"}
,
"shape172390":{"x":351,"y":311,"w":36,"h":36,"stylemods":[{"sel":"div.shape172390Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape172390Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape172390.png"}
,
"text172392":{"x":34,"y":249,"w":300,"h":183,"txtscale":100}
,
"image178167":{"x":33,"y":209,"w":385,"h":262,"i":"images/text_bg.png"}
,
"shape178169":{"x":404,"y":317,"w":36,"h":36,"stylemods":[{"sel":"div.shape178169Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape178169Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape178169.png"}
,
"text178170":{"x":56,"y":235,"w":352,"h":234,"txtscale":100}
,
"image175832":{"x":86,"y":255,"w":483,"h":230,"i":"images/text_bg.png"}
,
"shape175834":{"x":299,"y":476,"w":36,"h":36,"stylemods":[{"sel":"div.shape175834Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape175834Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape175834.png"}
,
"text175835":{"x":110,"y":281,"w":435,"h":190,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_icon.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/bg.png','images/text_bg.png','images/question_mark.png','images/concern.png','images/influence.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/button21689.png','images/button21689_over.png','images/button21689_down.png','images/button21689_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366733.png','images/shape366731.png','images/shape366729.png','images/shape366727.png','images/shape366725.png','images/shape172390.png','images/shape178169.png','images/shape175834.png']
}}
