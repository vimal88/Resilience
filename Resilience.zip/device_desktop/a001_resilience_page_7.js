DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image38007":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"button293038":{"x":650,"y":299,"w":47,"h":54,"stylemods":[{"sel":"div.button293038Text","decl":" { position:absolute; left:3px; top:2px; width:37px; height:46px;}"},{"sel":"span.button293038Text","decl":" { display:table-cell; position:relative; width:37px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button293038.png","irol":"images/button293038_over.png","ion":"images/button293038_down.png","idis":"images/button293038_disabled.png"}
,
"button293027":{"x":290,"y":299,"w":47,"h":54,"stylemods":[{"sel":"div.button293027Text","decl":" { position:absolute; left:3px; top:2px; width:37px; height:46px;}"},{"sel":"span.button293027Text","decl":" { display:table-cell; position:relative; width:37px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button293027.png","irol":"images/button293027_over.png","ion":"images/button293027_down.png","idis":"images/button293027_disabled.png"}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":1012,"h":585,"i":"images/bg_voilet.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"text38077":{"x":201,"y":17,"w":607,"h":36,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366937":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366937Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366937Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366937.png"}
,
"shape366935":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366935Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366935Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366935.png"}
,
"image38067":{"x":257,"y":88,"w":494,"h":433,"i":"images/text_bg.png"}
,
"text38068":{"x":201,"y":122,"w":607,"h":53,"txtscale":100}
,
"text38069":{"x":286,"y":172,"w":437,"h":36,"txtscale":100}
,
"text43530":{"x":286,"y":207,"w":437,"h":79,"txtscale":100}
,
"text38567":{"x":336,"y":366,"w":85,"h":35,"txtscale":100}
,
"image39041":{"x":343,"y":404,"w":55,"h":98,"i":"images/jelly.png"}
,
"text38740":{"x":574,"y":366,"w":85,"h":37,"txtscale":100}
,
"image39144":{"x":569,"y":404,"w":93,"h":104,"i":"images/rock.png"}
,
"button41227":{"x":804,"y":596,"w":137,"h":54,"stylemods":[{"sel":"div.button41227Text","decl":" { position:absolute; left:4px; top:2px; width:125px; height:46px;}"},{"sel":"span.button41227Text","decl":" { display:table-cell; position:relative; width:125px; height:46px; vertical-align:middle; text-align:center; line-height:21px; font-size:21px; font-family:\"Cutive\"; font-weight:bold; color:#ffffff;}"}],"i":"images/button41227.png","irol":"images/button41227_over.png","ion":"images/button41227_down.png","idis":"images/button41227_disabled.png"}
,
"image293062":{"x":304,"y":313,"w":388,"h":27,"i":"images/bg2.png"}
,
"shape293060":{"x":337,"y":318,"w":316,"h":17,"stylemods":[{"sel":"div.shape293060Text","decl":" { position:absolute; left:2px; top:2px; width:308px; height:9px;}"},{"sel":"span.shape293060Text","decl":" { display:table-cell; position:relative; width:308px; height:9px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293060.png"}
,
"shape293058":{"x":335,"y":312,"w":322,"h":28,"stylemods":[{"sel":"div.shape293058Text","decl":" { position:absolute; left:2px; top:2px; width:314px; height:20px;}"},{"sel":"span.shape293058Text","decl":" { display:table-cell; position:relative; width:314px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293058.png"}
,
"shape293056":{"x":398,"y":312,"w":259,"h":28,"stylemods":[{"sel":"div.shape293056Text","decl":" { position:absolute; left:2px; top:2px; width:251px; height:20px;}"},{"sel":"span.shape293056Text","decl":" { display:table-cell; position:relative; width:251px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293056.png"}
,
"shape293054":{"x":461,"y":312,"w":196,"h":28,"stylemods":[{"sel":"div.shape293054Text","decl":" { position:absolute; left:2px; top:2px; width:188px; height:20px;}"},{"sel":"span.shape293054Text","decl":" { display:table-cell; position:relative; width:188px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293054.png"}
,
"shape293052":{"x":525,"y":312,"w":132,"h":28,"stylemods":[{"sel":"div.shape293052Text","decl":" { position:absolute; left:2px; top:2px; width:124px; height:20px;}"},{"sel":"span.shape293052Text","decl":" { display:table-cell; position:relative; width:124px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293052.png"}
,
"shape293050":{"x":589,"y":312,"w":68,"h":28,"stylemods":[{"sel":"div.shape293050Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:20px;}"},{"sel":"span.shape293050Text","decl":" { display:table-cell; position:relative; width:60px; height:20px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293050.png"}
,
"shape293048":{"x":310,"y":315,"w":17,"h":22,"stylemods":[{"sel":"div.shape293048Text","decl":" { position:absolute; left:2px; top:2px; width:9px; height:14px;}"},{"sel":"span.shape293048Text","decl":" { display:table-cell; position:relative; width:9px; height:14px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293048.png"}
,
"shape293046":{"x":667,"y":316,"w":17,"h":21,"stylemods":[{"sel":"div.shape293046Text","decl":" { position:absolute; left:3px; top:3px; width:9px; height:13px;}"},{"sel":"span.shape293046Text","decl":" { display:table-cell; position:relative; width:9px; height:13px; vertical-align:middle; text-align:center; line-height:13px; font-size:13px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape293046.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/text_bg.png','images/menu_iconwhite.png','images/jelly.png','images/rock.png','images/bg_voilet.png','images/bg2.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/button293038.png','images/button293038_over.png','images/button293038_down.png','images/button293038_disabled.png','images/button293027.png','images/button293027_over.png','images/button293027_down.png','images/button293027_disabled.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/button41227.png','images/button41227_over.png','images/button41227_down.png','images/button41227_disabled.png','images/shape293060.png','images/shape293058.png','images/shape293056.png','images/shape293054.png','images/shape293052.png','images/shape293050.png','images/shape293048.png','images/shape293046.png']
}}
