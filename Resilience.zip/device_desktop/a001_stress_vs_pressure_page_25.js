DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image38007":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"button156687":{"x":257,"y":277,"w":141,"h":60,"stylemods":[{"sel":"div.button156687Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button156687Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button156687.png","irol":"images/button156687_over.png","ion":"images/button156687_down.png","idis":"images/button156687_disabled.png"}
,
"button156699":{"x":257,"y":342,"w":141,"h":60,"stylemods":[{"sel":"div.button156699Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button156699Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button156699.png","irol":"images/button156699_over.png","ion":"images/button156699_down.png","idis":"images/button156699_disabled.png"}
,
"button156711":{"x":257,"y":406,"w":141,"h":60,"stylemods":[{"sel":"div.button156711Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button156711Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button156711.png","irol":"images/button156711_over.png","ion":"images/button156711_down.png","idis":"images/button156711_disabled.png"}
,
"button156723":{"x":257,"y":471,"w":141,"h":60,"stylemods":[{"sel":"div.button156723Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button156723Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button156723.png","irol":"images/button156723_over.png","ion":"images/button156723_down.png","idis":"images/button156723_disabled.png"}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":1012,"h":585,"i":"images/bg_voilet.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21689.png","irol":"images/button21689_over.png","ion":"images/button21689_down.png","idis":"images/button21689_disabled.png"}
,
"text38077":{"x":201,"y":17,"w":607,"h":36,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366845":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366845.png"}
,
"shape366843":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366843.png"}
,
"shape366841":{"x":378,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366841.png"}
,
"text156678":{"x":201,"y":88,"w":607,"h":53,"txtscale":100}
,
"text156679":{"x":263,"y":149,"w":498,"h":113,"txtscale":100}
,
"image156681":{"x":261,"y":279,"w":137,"h":55,"i":"images/button.png"}
,
"text156682":{"x":263,"y":292,"w":133,"h":28,"txtscale":100}
,
"image156693":{"x":261,"y":344,"w":137,"h":55,"i":"images/button.png"}
,
"text156694":{"x":263,"y":357,"w":133,"h":28,"txtscale":100}
,
"image156705":{"x":261,"y":408,"w":137,"h":55,"i":"images/button.png"}
,
"text156706":{"x":263,"y":421,"w":133,"h":29,"txtscale":100}
,
"image156717":{"x":261,"y":473,"w":137,"h":55,"i":"images/button.png"}
,
"text156718":{"x":263,"y":486,"w":133,"h":26,"txtscale":100}
,
"image156730":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape156732":{"x":402,"y":289,"w":36,"h":36,"stylemods":[{"sel":"div.shape156732Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape156732Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape156732.png"}
,
"text156733":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text156734":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image156743":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape156745":{"x":402,"y":354,"w":36,"h":36,"stylemods":[{"sel":"div.shape156745Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape156745Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape156745.png"}
,
"text156746":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text156747":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image156756":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape156758":{"x":402,"y":419,"w":36,"h":36,"stylemods":[{"sel":"div.shape156758Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape156758Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape156758.png"}
,
"text156759":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text156760":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image156769":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape156771":{"x":402,"y":483,"w":36,"h":36,"stylemods":[{"sel":"div.shape156771Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape156771Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape156771.png"}
,
"text156772":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text156773":{"x":455,"y":324,"w":300,"h":174,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/button.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/button21689.png','images/button21689_over.png','images/button21689_down.png','images/button21689_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/button156687.png','images/button156687_over.png','images/button156687_down.png','images/button156687_disabled.png','images/button156699.png','images/button156699_over.png','images/button156699_down.png','images/button156699_disabled.png','images/button156711.png','images/button156711_over.png','images/button156711_down.png','images/button156711_disabled.png','images/button156723.png','images/button156723_over.png','images/button156723_down.png','images/button156723_disabled.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape156732.png','images/shape156745.png','images/shape156758.png','images/shape156771.png']
}}
