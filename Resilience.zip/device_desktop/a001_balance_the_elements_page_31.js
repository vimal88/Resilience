DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image38007":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"button340044":{"x":254,"y":317,"w":128,"h":108,"stylemods":[{"sel":"div.button340044Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button340044Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button340044.png","irol":"images/button340044_over.png","ion":"images/button340044_down.png","idis":"images/button340044_disabled.png"}
,
"button341307":{"x":451,"y":318,"w":128,"h":108,"stylemods":[{"sel":"div.button341307Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button341307Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button341307.png","irol":"images/button341307_over.png","ion":"images/button341307_down.png","idis":"images/button341307_disabled.png"}
,
"button341988":{"x":649,"y":318,"w":128,"h":108,"stylemods":[{"sel":"div.button341988Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button341988Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button341988.png","irol":"images/button341988_over.png","ion":"images/button341988_down.png","idis":"images/button341988_disabled.png"}
,
"button342527":{"x":254,"y":438,"w":128,"h":108,"stylemods":[{"sel":"div.button342527Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button342527Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button342527.png","irol":"images/button342527_over.png","ion":"images/button342527_down.png","idis":"images/button342527_disabled.png"}
,
"button343995":{"x":452,"y":437,"w":128,"h":108,"stylemods":[{"sel":"div.button343995Text","decl":" { position:absolute; left:8px; top:2px; width:108px; height:100px;}"},{"sel":"span.button343995Text","decl":" { display:table-cell; position:relative; width:108px; height:100px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button343995.png","irol":"images/button343995_over.png","ion":"images/button343995_down.png","idis":"images/button343995_disabled.png"}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":1012,"h":585,"i":"images/bg_voilet.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21689.png","irol":"images/button21689_over.png","ion":"images/button21689_down.png","idis":"images/button21689_disabled.png"}
,
"text38077":{"x":201,"y":17,"w":607,"h":36,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366800":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366800Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366800Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366800.png"}
,
"shape366798":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366798Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366798Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366798.png"}
,
"shape366796":{"x":378,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366796Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366796Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366796.png"}
,
"shape366794":{"x":436,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366794Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366794Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366794.png"}
,
"image159408":{"x":455,"y":436,"w":125,"h":108,"i":"images/get_physical.png"}
,
"image159323":{"x":258,"y":436,"w":125,"h":110,"i":"images/feed_the_engine.png"}
,
"image159268":{"x":652,"y":317,"w":125,"h":108,"i":"images/me_time.png"}
,
"image159215":{"x":455,"y":317,"w":125,"h":110,"i":"images/switch_off.png"}
,
"image158808":{"x":258,"y":317,"w":125,"h":114,"i":"images/talk_it_out.png"}
,
"text335950":{"x":457,"y":446,"w":116,"h":31,"txtscale":100}
,
"text338454":{"x":272,"y":444,"w":96,"h":58,"txtscale":100}
,
"text337162":{"x":666,"y":329,"w":96,"h":28,"txtscale":100}
,
"text336739":{"x":469,"y":332,"w":96,"h":28,"txtscale":100}
,
"text336158":{"x":271,"y":332,"w":96,"h":28,"txtscale":100}
,
"image158965":{"x":204,"y":348,"w":43,"h":37,"i":"images/uncheck.png"}
,
"image159060":{"x":214,"y":338,"w":43,"h":37,"i":"images/check.png"}
,
"image159540":{"x":403,"y":348,"w":43,"h":37,"i":"images/uncheck.png"}
,
"image159537":{"x":413,"y":338,"w":43,"h":37,"i":"images/check.png"}
,
"image159734":{"x":599,"y":348,"w":43,"h":37,"i":"images/uncheck.png"}
,
"image159731":{"x":609,"y":338,"w":43,"h":37,"i":"images/check.png"}
,
"image159915":{"x":206,"y":467,"w":43,"h":37,"i":"images/uncheck.png"}
,
"image159918":{"x":216,"y":457,"w":43,"h":37,"i":"images/check.png"}
,
"image160305":{"x":403,"y":467,"w":43,"h":37,"i":"images/uncheck.png"}
,
"image160308":{"x":413,"y":457,"w":43,"h":37,"i":"images/check.png"}
,
"image88525":{"x":255,"y":148,"w":492,"h":153,"i":"images/text_bg.png"}
,
"text88526":{"x":201,"y":88,"w":607,"h":53,"txtscale":100}
,
"text88527":{"x":285,"y":172,"w":431,"h":110,"txtscale":100}
,
"image166079":{"x":400,"y":312,"w":349,"h":183,"i":"images/text_bg.png"}
,
"shape166081":{"x":371,"y":346,"w":36,"h":36,"stylemods":[{"sel":"div.shape166081Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape166081Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape166081.png"}
,
"text166082":{"x":424,"y":327,"w":223,"h":29,"txtscale":100}
,
"text166083":{"x":424,"y":365,"w":300,"h":117,"txtscale":100}
,
"image166497":{"x":788,"y":272,"w":215,"h":317,"i":"images/text_bg.png"}
,
"shape166499":{"x":759,"y":346,"w":36,"h":36,"stylemods":[{"sel":"div.shape166499Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape166499Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape166499.png"}
,
"text166500":{"x":802,"y":287,"w":181,"h":29,"txtscale":100}
,
"text166501":{"x":802,"y":315,"w":194,"h":251,"txtscale":100}
,
"image168771":{"x":590,"y":312,"w":349,"h":262,"i":"images/text_bg.png"}
,
"shape168773":{"x":561,"y":346,"w":36,"h":36,"stylemods":[{"sel":"div.shape168773Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape168773Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape168773.png"}
,
"text168774":{"x":614,"y":327,"w":298,"h":29,"txtscale":100}
,
"text168775":{"x":614,"y":365,"w":300,"h":213,"txtscale":100}
,
"image169543":{"x":400,"y":312,"w":349,"h":232,"i":"images/text_bg.png"}
,
"shape169545":{"x":371,"y":467,"w":36,"h":36,"stylemods":[{"sel":"div.shape169545Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape169545Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape169545.png"}
,
"text169546":{"x":424,"y":327,"w":223,"h":29,"txtscale":100}
,
"text169547":{"x":424,"y":365,"w":309,"h":157,"txtscale":100}
,
"image170139":{"x":592,"y":332,"w":349,"h":212,"i":"images/text_bg.png"}
,
"shape170141":{"x":563,"y":467,"w":36,"h":36,"stylemods":[{"sel":"div.shape170141Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape170141Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape170141.png"}
,
"text170142":{"x":616,"y":347,"w":223,"h":29,"txtscale":100}
,
"text170143":{"x":616,"y":385,"w":309,"h":157,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/talk_it_out.png','images/uncheck.png','images/check.png','images/switch_off.png','images/me_time.png','images/feed_the_engine.png','images/get_physical.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/button21689.png','images/button21689_over.png','images/button21689_down.png','images/button21689_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape23327.png','images/button340044.png','images/button340044_over.png','images/button340044_down.png','images/button340044_disabled.png','images/button341307.png','images/button341307_over.png','images/button341307_down.png','images/button341307_disabled.png','images/button341988.png','images/button341988_over.png','images/button341988_down.png','images/button341988_disabled.png','images/button342527.png','images/button342527_over.png','images/button342527_down.png','images/button342527_disabled.png','images/button343995.png','images/button343995_over.png','images/button343995_down.png','images/button343995_disabled.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366800.png','images/shape366798.png','images/shape366796.png','images/shape366794.png','images/shape166081.png','images/shape166499.png','images/shape168773.png','images/shape169545.png','images/shape170141.png']
}}
