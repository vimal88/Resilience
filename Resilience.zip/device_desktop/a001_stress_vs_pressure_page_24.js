DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image38007":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_iconwhite.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"button143478":{"x":257,"y":277,"w":141,"h":60,"stylemods":[{"sel":"div.button143478Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button143478Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button143478.png","irol":"images/button143478_over.png","ion":"images/button143478_down.png","idis":"images/button143478_disabled.png"}
,
"button143578":{"x":257,"y":342,"w":141,"h":60,"stylemods":[{"sel":"div.button143578Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button143578Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button143578.png","irol":"images/button143578_over.png","ion":"images/button143578_down.png","idis":"images/button143578_disabled.png"}
,
"button143597":{"x":257,"y":406,"w":141,"h":60,"stylemods":[{"sel":"div.button143597Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button143597Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button143597.png","irol":"images/button143597_over.png","ion":"images/button143597_down.png","idis":"images/button143597_disabled.png"}
,
"button143610":{"x":257,"y":471,"w":141,"h":60,"stylemods":[{"sel":"div.button143610Text","decl":" { position:absolute; left:5px; top:2px; width:127px; height:52px;}"},{"sel":"span.button143610Text","decl":" { display:table-cell; position:relative; width:127px; height:52px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button143610.png","irol":"images/button143610_over.png","ion":"images/button143610_down.png","idis":"images/button143610_disabled.png"}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image61230":{"x":0,"y":0,"w":1012,"h":585,"i":"images/bg_voilet.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21689.png","irol":"images/button21689_over.png","ion":"images/button21689_down.png","idis":"images/button21689_disabled.png"}
,
"text38077":{"x":201,"y":17,"w":607,"h":36,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366845":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366845Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366845Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366845.png"}
,
"shape366843":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366843Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366843Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366843.png"}
,
"shape366841":{"x":378,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366841Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366841Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366841.png"}
,
"text142747":{"x":201,"y":88,"w":607,"h":53,"txtscale":100}
,
"text142748":{"x":263,"y":149,"w":482,"h":112,"txtscale":100}
,
"image143318":{"x":261,"y":279,"w":137,"h":55,"i":"images/button.png"}
,
"text143100":{"x":263,"y":292,"w":133,"h":28,"txtscale":100}
,
"image143582":{"x":261,"y":344,"w":137,"h":55,"i":"images/button.png"}
,
"text143678":{"x":263,"y":357,"w":133,"h":28,"txtscale":100}
,
"image143591":{"x":261,"y":408,"w":137,"h":55,"i":"images/button.png"}
,
"text143592":{"x":263,"y":421,"w":133,"h":53,"txtscale":100}
,
"image143614":{"x":261,"y":473,"w":137,"h":55,"i":"images/button.png"}
,
"text143612":{"x":263,"y":486,"w":133,"h":26,"txtscale":100}
,
"image144950":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape145044":{"x":402,"y":289,"w":36,"h":36,"stylemods":[{"sel":"div.shape145044Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape145044Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape145044.png"}
,
"text142792":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text142793":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image145532":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape145534":{"x":402,"y":354,"w":36,"h":36,"stylemods":[{"sel":"div.shape145534Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape145534Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape145534.png"}
,
"text145535":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text145536":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image145615":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape145617":{"x":402,"y":419,"w":36,"h":36,"stylemods":[{"sel":"div.shape145617Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape145617Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape145617.png"}
,
"text145618":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text145619":{"x":455,"y":324,"w":300,"h":183,"txtscale":100}
,
"image145639":{"x":431,"y":271,"w":349,"h":266,"i":"images/text_bg.png"}
,
"shape145641":{"x":402,"y":483,"w":36,"h":36,"stylemods":[{"sel":"div.shape145641Text","decl":" { position:absolute; left:2px; top:2px; width:28px; height:28px;}"},{"sel":"span.shape145641Text","decl":" { display:table-cell; position:relative; width:28px; height:28px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape145641.png"}
,
"text145642":{"x":455,"y":286,"w":223,"h":29,"txtscale":100}
,
"text145643":{"x":455,"y":324,"w":300,"h":209,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/text_bg.png','images/menu_iconwhite.png','images/bg_voilet.png','images/button.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/button21689.png','images/button21689_over.png','images/button21689_down.png','images/button21689_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape23327.png','images/button143478.png','images/button143478_over.png','images/button143478_down.png','images/button143478_disabled.png','images/button143578.png','images/button143578_over.png','images/button143578_down.png','images/button143578_disabled.png','images/button143597.png','images/button143597_over.png','images/button143597_down.png','images/button143597_disabled.png','images/button143610.png','images/button143610_over.png','images/button143610_down.png','images/button143610_disabled.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366845.png','images/shape366843.png','images/shape366841.png','images/shape145044.png','images/shape145534.png','images/shape145617.png','images/shape145641.png']
}}
