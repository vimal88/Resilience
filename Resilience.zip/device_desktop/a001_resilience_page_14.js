DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"image5712":{"x":18,"y":14,"w":38,"h":35,"i":"images/menu_icon.png"}
,
"shape23327":{"x":-3,"y":-1,"w":1014,"h":131,"stylemods":[{"sel":"div.shape23327Text","decl":" { position:absolute; left:2px; top:2px; width:1006px; height:123px;}"},{"sel":"span.shape23327Text","decl":" { display:table-cell; position:relative; width:1006px; height:123px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape23327.png"}
,
"image23506":{"x":0,"y":129,"w":1009,"h":534,"i":"images/menu_bg.png"}
,
"image23329":{"x":19,"y":10,"w":26,"h":37,"i":"images/menu_hide.png"}
,
"image23332":{"x":460,"y":26,"w":89,"h":77,"i":"images/jba-branding-160.png"}
,
"image23334":{"x":0,"y":213,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image234954":{"x":0,"y":267,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23336":{"x":0,"y":322,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23338":{"x":0,"y":375,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23340":{"x":0,"y":429,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23342":{"x":0,"y":483,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image232939":{"x":0,"y":537,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image233039":{"x":0,"y":591,"w":1009,"h":2,"i":"images/horizontal_line.png"}
,
"image23416":{"x":0,"y":159,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image234952":{"x":0,"y":214,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23414":{"x":0,"y":268,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23412":{"x":0,"y":322,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23410":{"x":0,"y":376,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image23408":{"x":0,"y":430,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image232937":{"x":0,"y":484,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"image233037":{"x":0,"y":538,"w":1009,"h":54,"i":"images/menu_selected.png"}
,
"text23343":{"x":0,"y":173,"w":1009,"h":40,"txtscale":100}
,
"text234944":{"x":0,"y":227,"w":1009,"h":40,"txtscale":100}
,
"text23349":{"x":0,"y":281,"w":1009,"h":40,"txtscale":100}
,
"text23352":{"x":0,"y":335,"w":1009,"h":40,"txtscale":100}
,
"text23355":{"x":0,"y":389,"w":1009,"h":40,"txtscale":100}
,
"text23358":{"x":0,"y":444,"w":1009,"h":40,"txtscale":100}
,
"text232929":{"x":0,"y":498,"w":1009,"h":40,"txtscale":100}
,
"text233029":{"x":0,"y":551,"w":1009,"h":40,"txtscale":100}
,
"shape141298":{"x":-91,"y":125,"w":53,"h":54,"stylemods":[{"sel":"div.shape141298Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape141298Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape141298.png"}
,
"shape231677":{"x":-91,"y":185,"w":53,"h":54,"stylemods":[{"sel":"div.shape231677Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231677Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231677.png"}
,
"shape231747":{"x":-91,"y":245,"w":53,"h":54,"stylemods":[{"sel":"div.shape231747Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231747Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231747.png"}
,
"shape231826":{"x":-91,"y":305,"w":53,"h":54,"stylemods":[{"sel":"div.shape231826Text","decl":" { position:absolute; left:3px; top:3px; width:45px; height:46px;}"},{"sel":"span.shape231826Text","decl":" { display:table-cell; position:relative; width:45px; height:46px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape231826.png"}
,
"image24751":{"x":0,"y":0,"w":1010,"h":662,"i":"images/bg.png"}
,
"button21550":{"x":143,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21550Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21550Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21550.png","irol":"images/button21550_over.png","ion":"images/button21550_down.png","idis":"images/button21550_disabled.png"}
,
"button21689":{"x":792,"y":592,"w":68,"h":63,"stylemods":[{"sel":"div.button21689Text","decl":" { position:absolute; left:2px; top:2px; width:60px; height:55px;}"},{"sel":"span.button21689Text","decl":" { display:table-cell; position:relative; width:60px; height:55px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/button21689.png","irol":"images/button21689_over.png","ion":"images/button21689_down.png","idis":"images/button21689_disabled.png"}
,
"text24400":{"x":201,"y":17,"w":607,"h":35,"txtscale":100}
,
"shape365091":{"x":262,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365091Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365091Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365091.png"}
,
"shape365089":{"x":378,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365089Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365089Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365089.png"}
,
"shape365087":{"x":494,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365087Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365087Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365087.png"}
,
"shape365085":{"x":610,"y":615,"w":118,"h":16,"stylemods":[{"sel":"div.shape365085Text","decl":" { position:absolute; left:2px; top:2px; width:110px; height:8px;}"},{"sel":"span.shape365085Text","decl":" { display:table-cell; position:relative; width:110px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape365085.png"}
,
"shape366937":{"x":262,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366937Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366937Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366937.png"}
,
"shape366935":{"x":320,"y":615,"w":60,"h":16,"stylemods":[{"sel":"div.shape366935Text","decl":" { position:absolute; left:2px; top:2px; width:52px; height:8px;}"},{"sel":"span.shape366935Text","decl":" { display:table-cell; position:relative; width:52px; height:8px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"i":"images/shape366935.png"}
,
"image58750":{"x":257,"y":158,"w":494,"h":164,"i":"images/text_bg.png"}
,
"text58751":{"x":201,"y":88,"w":607,"h":53,"txtscale":100}
,
"text58752":{"x":286,"y":186,"w":437,"h":117,"txtscale":100}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,"preload":['images/jba-branding-160.png','images/menu_icon.png','images/menu_bg.png','images/menu_hide.png','images/horizontal_line.png','images/menu_selected.png','images/prev-arrow1.png','images/next_hover.png','images/bg.png','images/text_bg.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/button21550.png','images/button21550_over.png','images/button21550_down.png','images/button21550_disabled.png','images/button21689.png','images/button21689_over.png','images/button21689_down.png','images/button21689_disabled.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png','images/shape23327.png','images/shape141298.png','images/shape231677.png','images/shape231747.png','images/shape231826.png','images/shape365091.png','images/shape365089.png','images/shape365087.png','images/shape365085.png','images/shape366937.png','images/shape366935.png']
}}
